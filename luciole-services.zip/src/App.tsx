/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 */

import React, { useEffect, useState } from "react";
import { Navbar } from "./components/Navbar";
import { Hero } from "./components/Hero";
import { Marquee } from "./components/Marquee";
import { Services } from "./components/Services";
import { Showcase } from "./components/Showcase";
import { AudioStudio } from "./components/AudioStudio";
import { ProjectEstimator } from "./components/ProjectEstimator";
import { AboutAndCounter } from "./components/AboutAndCounter";
import { ContactForm } from "./components/ContactForm";
import { Footer } from "./components/Footer";
import { TESTIMONIALS } from "./data";
import { ChevronRight } from "lucide-react";

export default function App() {
  const [activeTestimonial, setActiveTestimonial] = useState(0);

  useEffect(() => {
    // Dynamic tab document title setup
    document.title = "Luciole Services — Création Web, Mobile & Studio Audio Professionnel";

    // Interval to slide client reviews automatically
    const interval = setInterval(() => {
      setActiveTestimonial((prev) => (prev + 1) % TESTIMONIALS.length);
    }, 7000);
    return () => clearInterval(interval);
  }, []);

  const handleContactAnchor = () => {
    const contactSection = document.getElementById("contact");
    if (contactSection) {
      contactSection.scrollIntoView({ behavior: "smooth" });
    }
  };

  return (
    <div className="bg-transparent text-slate-100 min-h-screen font-sans selection:bg-gold/30 selection:text-navy-dark leading-relaxed">
      {/* 1. Header Navigation */}
      <Navbar onContactClick={handleContactAnchor} />

      {/* 2. Hero slider introduction & particle wave */}
      <Hero />

      {/* 3. Infinite specialized marquee ribbon */}
      <Marquee />

      {/* 4. Core corporate capabilities grid */}
      <Services />

      {/* 5. Fluid showcases tabs list */}
      <Showcase />

      {/* 6. High fidelity Voiceovers & mixer workspace */}
      <AudioStudio />

      {/* 7. Instant configuration budgeting simulator */}
      <ProjectEstimator />

      {/* 8. Progressive counting stats and bio */}
      <AboutAndCounter />

      {/* 9. Visual Customer Reviews carousel */}
      <section className="py-24 bg-navy-dark/45 backdrop-blur-md text-white relative z-30 border-y border-white/5">
        <div className="max-w-7xl mx-auto px-6">
          <div className="text-center max-w-3xl mx-auto mb-16">
            <span className="text-gold font-bold uppercase tracking-[0.2em] text-xs block mb-3">
              Témoignages Clients
            </span>
            <h2 className="font-display font-black text-3xl sm:text-4xl text-white leading-tight">
              Ils nous font confiance.
            </h2>
          </div>

          <div className="max-w-3xl mx-auto bg-white/5 border border-white/10 rounded-3xl p-8 sm:p-12 relative overflow-hidden backdrop-blur-sm shadow-xl min-h-[260px] flex flex-col justify-between">
            {TESTIMONIALS.map((t, index) => (
              <div
                key={t.id}
                className={`transition-all duration-700 flex flex-col ${
                  index === activeTestimonial
                    ? "opacity-100 scale-100 relative pointer-events-auto"
                    : "opacity-0 scale-95 absolute pointer-events-none inset-x-8 top-12"
                }`}
              >
                {/* 5-Star Indicator */}
                <div className="flex items-center gap-1 text-gold mb-6 text-lg">
                  {Array.from({ length: t.stars }).map((_, i) => (
                    <span key={i}>★</span>
                  ))}
                </div>

                <p className="text-gray-200 text-base sm:text-lg italic leading-relaxed mb-8">
                  "{t.content}"
                </p>

                <div className="flex items-center gap-4 border-t border-white/5 pt-6">
                  {/* Styled customized vector initials avatar to avoid heavy images loading */}
                  <div className="w-12 h-12 rounded-full bg-gold/15 border border-gold/10 flex items-center justify-center text-xl select-none">
                    {t.avatarSvg}
                  </div>
                  <div>
                    <h4 className="font-display font-bold text-sm text-white leading-none mb-1">
                      {t.author}
                    </h4>
                    <span className="text-[10px] text-gray-400 font-semibold tracking-wider uppercase block">
                      {t.role} • {t.location}
                    </span>
                  </div>
                </div>
              </div>
            ))}

            {/* Slider dots trackers */}
            <div className="flex items-center justify-center gap-2 mt-8">
              {TESTIMONIALS.map((_, i) => (
                <button
                  key={i}
                  onClick={() => setActiveTestimonial(i)}
                  className={`h-1.5 rounded-full transition-all duration-300 ${
                    i === activeTestimonial ? "w-6 bg-gold" : "w-1.5 bg-white/30"
                  }`}
                  aria-label={`Testimonial slide ${i + 1}`}
                />
              ))}
            </div>
          </div>
        </div>
      </section>

      {/* 10. Direct Contact interface */}
      <ContactForm />

      {/* 11. Footer credits mapping */}
      <Footer />

      {/* 12. Floating WhatsApp fast assistance */}
      <a
        href="https://wa.me/237699958089"
        target="_blank"
        rel="noopener noreferrer"
        aria-label="Contacter sur WhatsApp"
        className="fixed bottom-6 right-6 z-50 w-14 h-14 bg-[#25D366] text-white rounded-full flex items-center justify-center shadow-[0_8px_24px_rgba(37,211,102,0.4)] hover:shadow-[0_12px_32px_rgba(37,211,102,0.6)] transform hover:-translate-y-1 hover:scale-105 transition-all duration-300 cursor-pointer animate-bounce border border-white/10 group"
      >
        <span className="text-2xl">💬</span>
        <div className="absolute right-full mr-3 bg-white text-navy-dark text-xs font-bold py-2 px-3 rounded-lg shadow-xl border border-gray-100 hidden group-hover:block whitespace-nowrap animate-fadeUp">
          Besoin d'aide ? Parlons par WhatsApp !
        </div>
      </a>
    </div>
  );
}
