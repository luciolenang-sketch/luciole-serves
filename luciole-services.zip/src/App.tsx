import React, { useState, useEffect } from "react";
import { ChevronUp } from "lucide-react";
import Header from "./components/Header";
import Hero from "./components/Hero";
import Services from "./components/Services";
import Showcase from "./components/Showcase";
import AudioVideoSection from "./components/AudioVideoSection";
import AboutSection from "./components/AboutSection";
import MethodSection from "./components/MethodSection";
import Testimonials from "./components/Testimonials";
import ContactSection from "./components/ContactSection";
import Footer from "./components/Footer";

const marqueeTexts = [
  "Création de sites web vitrines & e-commerce",
  "Applications iOS & Android sur mesure",
  "Gestion et conception de bases de données",
  "Design graphique & identité visuelle",
  "Spots publicitaires entreprise audio & vidéo",
  "Voix off professionnelles",
  "Jingles & habillages sonores",
  "Maintenance & support technique"
];

export default function App() {
  const [showScrollTop, setShowScrollTop] = useState(false);

  useEffect(() => {
    const checkScroll = () => {
      setShowScrollTop(window.scrollY > 400);
    };
    window.addEventListener("scroll", checkScroll);
    return () => window.removeEventListener("scroll", checkScroll);
  }, []);

  const scrollToTop = () => {
    window.scrollTo({ top: 0, behavior: "smooth" });
  };

  return (
    <div className="font-sans text-slate-700 antialiased bg-slate-50 relative selection:bg-amber-400 selection:text-slate-950">
      {/* Header */}
      <Header />

      {/* Hero */}
      <Hero />

      {/* MARQUEE TEXT RUNNER EFFECT */}
      <div className="bg-amber-400 overflow-hidden whitespace-nowrap py-4 border-y border-slate-950/10 relative z-30 shadow-md">
        <div className="inline-flex animate-[marqueeScroll_30s_linear_infinite] gap-12 text-slate-950 font-black uppercase text-xs sm:text-sm tracking-wider">
          {/* Double content to ensure seamless loop */}
          {[...marqueeTexts, ...marqueeTexts].map((text, index) => (
            <span key={index} className="inline-flex items-center gap-2">
              <span className="text-slate-950 text-base">★</span>
              <span>{text}</span>
            </span>
          ))}
        </div>
      </div>

      <style>{`
        @keyframes marqueeScroll {
          0% {
            transform: translateX(0);
          }
          100% {
            transform: translateX(-50%);
          }
        }
      `}</style>

      {/* Services Grid */}
      <Services />

      {/* Showcase Portfolio */}
      <Showcase />

      {/* Audio / Video Studio Details */}
      <AudioVideoSection />

      {/* About Section */}
      <AboutSection />

      {/* Project Method Workflow */}
      <MethodSection />

      {/* Customer Testimonials reviews */}
      <Testimonials />

      {/* Contact Section */}
      <ContactSection />

      {/* Footer (with exact interactive social links requested) */}
      <Footer />

      {/* SCROLL TO TOP BUTTON ACCENTS */}
      <button
        onClick={scrollToTop}
        className={`fixed bottom-6 right-24 z-[999] w-12 h-12 rounded-full bg-slate-900 border border-slate-800 text-amber-400 flex items-center justify-center cursor-pointer shadow-2xl hover:bg-amber-400 hover:text-slate-950 active:scale-95 transition-all duration-300 ${
          showScrollTop ? "opacity-100 scale-100" : "opacity-0 scale-50 pointer-events-none"
        }`}
        aria-label="Retour en haut de page"
      >
        <ChevronUp className="w-5 h-5 font-black" />
      </button>
    </div>
  );
}
