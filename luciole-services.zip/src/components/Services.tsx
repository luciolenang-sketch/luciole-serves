/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 */

import React, { useState } from "react";
import { SERVICES } from "../data";
import { Service } from "../types";
import { Check, Info, Sparkles } from "lucide-react";

export const Services: React.FC = () => {
  const [selectedService, setSelectedService] = useState<Service | null>(null);

  return (
    <section id="services" className="py-24 bg-transparent text-slate-100">
      <div className="max-w-7xl mx-auto px-6">
        {/* Section header */}
        <div className="text-center max-w-3xl mx-auto mb-16">
          <span className="text-gold font-bold uppercase tracking-[0.2em] text-xs block mb-3">
            Nos Domaines d'Expertises
          </span>
          <h2 className="font-display font-black text-3xl sm:text-4xl text-white leading-tight mb-4">
            Des prestations haut de gamme, sans intermédiaire.
          </h2>
          <p className="text-slate-400 text-lg leading-relaxed">
            De la maquette au code de production, jusqu'à l'habillage sonore de votre publicité,
            découvrez des solutions pensées pour maximiser votre impact de marque.
          </p>
        </div>

        {/* Services Grid */}
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-8">
          {SERVICES.map((service) => (
            <div
              key={service.id}
              onClick={() => setSelectedService(service)}
              className="group bg-[#1e293b]/30 backdrop-blur-md rounded-2xl p-8 border border-white/5 hover:border-gold/30 hover:shadow-2xl hover:shadow-gold/5 transform hover:-translate-y-1.5 transition-all duration-300 cursor-pointer flex flex-col justify-between"
            >
              <div>
                {/* Header card icon state */}
                <div className="w-14 h-14 rounded-xl mb-6 flex items-center justify-center text-3xl bg-gold/10 border border-gold/20 text-gold group-hover:scale-110 group-hover:-rotate-3 transition duration-300">
                  {service.icon}
                </div>

                <h3 className="font-display font-black text-xl text-white mb-3 group-hover:text-gold transition duration-200">
                  {service.title}
                </h3>
                <p className="text-slate-400 text-sm leading-relaxed mb-6">
                  {service.description}
                </p>
              </div>

              {/* Expand details info */}
              <div className="border-t border-white/5 pt-4 flex items-center justify-between">
                <span className="text-[11px] font-bold tracking-widest text-slate-500 uppercase group-hover:text-gold transition">
                  En savoir plus
                </span>
                <Info size={16} className="text-slate-400 group-hover:text-gold transition" />
              </div>
            </div>
          ))}
        </div>

        {/* Interactive service details modal */}
        {selectedService && (
          <div className="fixed inset-0 z-55 bg-black/70 backdrop-blur-sm flex items-center justify-center p-6 animate-fadeUp">
            <div className="bg-[#0f172a] rounded-3xl max-w-lg w-full overflow-hidden shadow-2xl relative border border-white/10 text-white">
              {/* Modal header banner */}
              <div className="bg-gradient-to-tr from-[#1e293b] to-[#0f172a] text-white p-6 relative border-b border-white/5">
                <div className="flex items-center gap-4">
                  <div className="text-4xl">{selectedService.icon}</div>
                  <div>
                    <span className="text-[10px] font-bold text-gold uppercase tracking-widest block">
                      Fiche technique service
                    </span>
                    <h3 className="font-display font-black text-xl">
                      {selectedService.title}
                    </h3>
                  </div>
                </div>

                <button
                  onClick={() => setSelectedService(null)}
                  className="absolute top-4 right-4 text-white/60 hover:text-white hover:bg-white/10 p-1.5 rounded-full transition"
                  aria-label="Fermer"
                >
                  ✕
                </button>
              </div>

              {/* Inside detailed bulletin */}
              <div className="p-8">
                <h4 className="font-semibold text-sm text-slate-200 mb-4">
                  Ce que comprend notre prestation :
                </h4>
                <ul className="space-y-3 list-none m-0 p-0 mb-6">
                  {selectedService.features.map((feature, idx) => (
                    <li key={idx} className="flex items-start gap-3">
                      <div className="p-0.5 rounded-full bg-gold/15 text-gold shrink-0 mt-0.5">
                        <Check size={14} />
                      </div>
                      <span className="text-slate-300 text-sm leading-relaxed">{feature}</span>
                    </li>
                  ))}
                </ul>

                <p className="text-xs text-slate-500 italic mb-6 leading-relaxed">
                  * Toutes nos offres s'adaptent selon votre secteur. Vous obtiendrez des rapports de performance après déploiement.
                </p>

                <div className="flex gap-4">
                  <a
                    href="#estimator"
                    onClick={() => setSelectedService(null)}
                    className="flex-1 py-3 text-center rounded-xl font-bold bg-gold hover:bg-gold-light text-white transition text-sm flex items-center justify-center gap-1.5"
                  >
                    <Sparkles size={16} />
                    Estimer le coût
                  </a>
                  <button
                    onClick={() => setSelectedService(null)}
                    className="flex-1 py-3 rounded-xl font-bold border border-white/10 hover:bg-white/5 text-slate-300 text-sm transition"
                  >
                    Fermer
                  </button>
                </div>
              </div>
            </div>
          </div>
        )}
      </div>
    </section>
  );
};
