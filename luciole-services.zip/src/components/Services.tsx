import React from "react";
import {
  Globe,
  Smartphone,
  Database,
  Palette,
  Megaphone,
  Video,
  Mic,
  Music,
  Wrench,
  ArrowRight
} from "lucide-react";

const services = [
  {
    id: "site-web",
    icon: <Globe className="w-7 h-7 text-amber-600" />,
    title: "Création de sites web",
    description: "Sites vitrines, e-commerce, blogs et applications web sur-mesure, responsives et entièrement optimisés SEO."
  },
  {
    id: "app-mobile",
    icon: <Smartphone className="w-7 h-7 text-amber-600" />,
    title: "Applications iOS & Android",
    description: "Conception et développement d'applications mobiles d'excellence, fluides, intuitives et personnalisées."
  },
  {
    id: "database",
    icon: <Database className="w-7 h-7 text-amber-600" />,
    title: "Gestion de bases de données",
    description: "Architecture, modélisation, sécurisation, optimisation de requêtes et administration de données d'entreprise."
  },
  {
    id: "design-graphique",
    icon: <Palette className="w-7 h-7 text-amber-600" />,
    title: "Design graphique",
    description: "Logos haut-de-gamme, chartes graphiques de marque, maquettes interactives et supports publicitaires imprimés."
  },
  {
    id: "spots",
    icon: <Megaphone className="w-7 h-7 text-amber-600" />,
    title: "Spots publicitaires",
    description: "Conception de spots audio et vidéo captivants pour dynamiser de manière stratégique votre communication."
  },
  {
    id: "audiovisuel",
    icon: <Video className="w-7 h-7 text-amber-600" />,
    title: "Production audio & vidéo",
    description: "Montages narratifs, storyboards originaux, cadrages et traitement multimédia d'excellence."
  },
  {
    id: "voix-off",
    icon: <Mic className="w-7 h-7 text-amber-600" />,
    title: "Voix off professionnelle",
    description: "Enregistrement vocal premium pour vos vidéos d'entreprise, d'apprentissage, publicitaires ou animées."
  },
  {
    id: "jingles",
    icon: <Music className="w-7 h-7 text-amber-600" />,
    title: "Jingles & habillages sonores",
    description: "Conception sonore identitaire, signature d'entreprise mémorable et habillages uniques."
  },
  {
    id: "maintenance",
    icon: <Wrench className="w-7 h-7 text-amber-600" />,
    title: "Maintenance & support",
    description: "Suivi technique rigoureux, mises à jour critiques, audits de sécurité et assistance d'urgence continue."
  }
];

export default function Services() {
  return (
    <section id="services" className="py-24 bg-slate-50 border-t border-slate-100">
      <div className="max-w-7xl mx-auto px-6">
        {/* Section Heading */}
        <div className="text-center max-w-2xl mx-auto mb-16">
          <span className="text-amber-600 font-bold text-xs uppercase tracking-widest block mb-3">
            Nos services d'expert
          </span>
          <h2 className="font-display font-bold text-3xl sm:text-4xl text-slate-900 leading-tight mb-4">
            Des solutions complètes pour votre entreprise
          </h2>
          <p className="text-slate-500 text-sm sm:text-base leading-relaxed italic">
            De la conception digitale à la production audiovisuelle moderne, Luciole-services orchestre vos projets de croissance avec rigueur et créativité.
          </p>
        </div>

        {/* Services Grid */}
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-8">
          {services.map((service) => {
            const isPopular = service.id === "app-mobile";
            return (
              <div
                key={service.id}
                className={`bg-white rounded-2xl p-8 border hover:shadow-2xl hover:shadow-slate-200/50 hover:-translate-y-2 transition-all duration-300 group flex flex-col justify-between relative ${
                  isPopular
                    ? "border-2 border-amber-400 shadow-xl"
                    : "border-slate-200 shadow-sm"
                }`}
              >
                {isPopular && (
                  <span className="absolute top-4 right-4 bg-amber-400 text-slate-900 text-[10px] font-extrabold px-2 py-1 rounded uppercase tracking-wider">
                    Populaire
                  </span>
                )}
                <div>
                  {/* Icon Wrapper with glowing soft yellow background */}
                  <div className="w-12 h-12 rounded-xl bg-amber-50 flex items-center justify-center mb-6 transition-transform duration-300 group-hover:rotate-6 group-hover:scale-105">
                    {service.icon}
                  </div>
                  
                  <h3 className="font-display font-bold text-lg text-slate-900 mb-3 group-hover:text-amber-600 transition-colors duration-200">
                    {service.title}
                  </h3>
                  
                  <p className="text-slate-500 text-sm leading-relaxed mb-6">
                    {service.description}
                  </p>
                </div>

                {/* Decorative Subtle Line */}
                <div className="w-8 h-0.5 bg-amber-400 group-hover:w-full transition-all duration-300 mt-auto" />
              </div>
            );
          })}
        </div>

        {/* Call to action within Services */}
        <div className="mt-16 text-center animate-fadeIn">
          <p className="text-slate-600 text-sm mb-4 font-medium italic">
            Vous avez un projet en tête ? Laissez nos experts concevoir la solution idéale.
          </p>
          <a
            href="#contact"
            className="inline-flex items-center gap-2 bg-slate-900 hover:bg-amber-400 text-white hover:text-slate-950 px-8 py-4 rounded-lg font-bold transition-all duration-300 shadow-md hover:shadow-lg shadow-slate-900/10 hover:shadow-amber-400/20"
            style={{ animation: "pulseGlow 2.6s infinite" }}
          >
            Demander un devis gratuit <ArrowRight className="w-4 h-4" />
          </a>
        </div>
      </div>
    </section>
  );
}
