import React from "react";

interface LogoProps {
  className?: string;
  color?: string; // Hex color for the logo, default to brand slate-900 (or white where appropriate)
}

export default function Logo({ className = "w-8 h-8", color = "currentColor" }: LogoProps) {
  return (
    <svg
      viewBox="0 0 120 120"
      className={className}
      fill="none"
      xmlns="http://www.w3.org/2000/svg"
    >
      {/* Top-Right/Bottom-Right Outer Crescent */}
      <path
        d="M 52 10 A 48 48 0 0 1 106 72 A 48 48 0 0 1 90 102 C 101 92 108 76 106 60 C 103 36 82 18 56 18 C 50 18 44 19 38 21 C 42 14 47 10 52 10 Z"
        fill={color}
      />
      {/* Bottom-Left/Top-Left Outer Crescent */}
      <path
        d="M 68 110 A 48 48 0 0 1 14 48 A 48 48 0 0 1 30 18 C 19 28 12 44 14 60 C 17 84 38 102 64 102 C 70 102 76 101 82 99 C 78 106 73 110 68 110 Z"
        fill={color}
      />
      {/* Elegant interlocking bold italic "LS" */}
      <text
        x="57"
        y="83"
        fontFamily="'Inter', 'Space Grotesk', 'Outfit', sans-serif"
        fontWeight="900"
        fontSize="54"
        fontStyle="italic"
        fill={color}
        textAnchor="middle"
        letterSpacing="-5"
      >
        LS
      </text>
    </svg>
  );
}
