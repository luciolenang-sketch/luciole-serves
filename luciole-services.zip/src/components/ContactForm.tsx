/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 */

import React, { useState } from "react";
import { Phone, Mail, MapPin, Send, CheckCircle2 } from "lucide-react";

export const ContactForm: React.FC = () => {
  const [name, setName] = useState("");
  const [phone, setPhone] = useState("");
  const [selectedService, setSelectedService] = useState("");
  const [message, setMessage] = useState("");
  const [submitted, setSubmitted] = useState(false);

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    if (!name || !phone || !message) return;

    // Simulate database insertion and state
    setSubmitted(true);
  };

  const handleReset = () => {
    setName("");
    setPhone("");
    setSelectedService("");
    setMessage("");
    setSubmitted(false);
  };

  return (
    <section id="contact" className="py-24 bg-transparent text-slate-100">
      <div className="max-w-7xl mx-auto px-6">
        <div className="grid grid-cols-1 lg:grid-cols-12 gap-12 items-stretch">
          {/* Left panel: company details cards */}
          <div className="lg:col-span-5 flex flex-col justify-between py-2">
            <div>
              <span className="text-gold font-bold uppercase tracking-[0.2em] text-xs block mb-3">
                Nous Recruter
              </span>
              <h2 className="font-display font-black text-3xl sm:text-4xl text-white leading-tight mb-4">
                Parlez-nous de votre projet.
              </h2>
              <p className="text-slate-400 text-base leading-relaxed mb-8">
                Remplissez notre formulaire de contact rapide en moins de 30 secondes. 
                Nous vous recontacterons sous 24 heures pour planifier un entretien d'opportunité gratuit.
              </p>
            </div>

            <div className="space-y-6">
              <div className="flex items-center gap-4 group">
                <div className="w-12 h-12 rounded-full bg-white/5 border border-white/5 text-gold group-hover:bg-gold group-hover:text-amber-950 flex items-center justify-center transition duration-300">
                  <Phone size={18} />
                </div>
                <div>
                   <h4 className="text-xs font-bold text-slate-500 uppercase tracking-wider leading-none mb-1">
                    Téléphone / WhatsApp
                  </h4>
                  <p className="text-sm font-extrabold text-white group-hover:text-gold transition">
                    +237 699 95 80 89
                  </p>
                </div>
              </div>

              <div className="flex items-center gap-4 group">
                <div className="w-12 h-12 rounded-full bg-white/5 border border-white/5 text-gold group-hover:bg-gold group-hover:text-amber-950 flex items-center justify-center transition duration-300">
                  <Mail size={18} />
                </div>
                <div>
                  <h4 className="text-xs font-bold text-slate-500 uppercase tracking-wider leading-none mb-1">
                    Email Direct
                  </h4>
                  <p className="text-sm font-extrabold text-white group-hover:text-gold transition">
                    luciole@services.com
                  </p>
                </div>
              </div>

              <div className="flex items-center gap-4 group">
                <div className="w-12 h-12 rounded-full bg-white/5 border border-white/5 text-gold group-hover:bg-gold group-hover:text-amber-950 flex items-center justify-center transition duration-300">
                  <MapPin size={18} />
                </div>
                <div>
                  <h4 className="text-xs font-bold text-slate-500 uppercase tracking-wider leading-none mb-1">
                    Siège de Service
                  </h4>
                  <p className="text-sm font-extrabold text-white group-hover:text-gold transition">
                    Douala, Cameroun (Afrique Centrale)
                  </p>
                </div>
              </div>
            </div>
          </div>

          {/* Right panel: custom contact form */}
          <div className="lg:col-span-7">
            {!submitted ? (
              <form
                onSubmit={handleSubmit}
                className="bg-[#1e293b]/30 backdrop-blur-md rounded-3xl p-6 sm:p-10 border border-white/5 shadow-xl flex flex-col gap-5 h-full justify-between"
              >
                <div className="grid grid-cols-1 sm:grid-cols-2 gap-5">
                  <div>
                    <label htmlFor="client-name" className="text-xs font-bold text-slate-400 uppercase tracking-wider block mb-2">
                      Nom complet *
                    </label>
                    <input
                      id="client-name"
                      type="text"
                      required
                      value={name}
                      onChange={(e) => setName(e.target.value)}
                      placeholder="Ex: Aïcha Ntsama"
                      className="w-full bg-[#020617]/50 border border-white/10 rounded-xl px-4 py-3.5 text-sm focus:outline-none focus:border-gold placeholder:text-white/20 text-white focus:ring-2 focus:ring-gold/10 transition"
                    />
                  </div>

                  <div>
                    <label htmlFor="client-phone" className="text-xs font-bold text-slate-400 uppercase tracking-wider block mb-2">
                      Numéro de Téléphone *
                    </label>
                    <input
                      id="client-phone"
                      type="tel"
                      required
                      value={phone}
                      onChange={(e) => setPhone(e.target.value)}
                      placeholder="Ex: +237 6XX XX XX XX"
                      className="w-full bg-[#020617]/50 border border-white/10 rounded-xl px-4 py-3.5 text-sm focus:outline-none focus:border-gold placeholder:text-white/20 text-white focus:ring-2 focus:ring-gold/10 transition"
                    />
                  </div>
                </div>

                <div>
                  <label htmlFor="service-select" className="text-xs font-bold text-slate-400 uppercase tracking-wider block mb-2">
                    Service Souhaité
                  </label>
                  <select
                    id="service-select"
                    value={selectedService}
                    onChange={(e) => setSelectedService(e.target.value)}
                    className="w-full bg-[#020617]/80 border border-white/10 rounded-xl px-4 py-3.5 text-sm focus:outline-none focus:border-gold focus:ring-2 focus:ring-gold/10 transition cursor-pointer text-white"
                  >
                    <option value="" className="bg-slate-900 text-white">Sélectionnez une catégorie...</option>
                    <option value="web" className="bg-slate-900 text-white">Création de site web</option>
                    <option value="app" className="bg-slate-900 text-white">Application mobile iOS/Android</option>
                    <option value="db" className="bg-slate-900 text-white">Bases de données & APIs</option>
                    <option value="brand" className="bg-slate-900 text-white">Logo & Charte Graphique</option>
                    <option value="jingle" className="bg-slate-900 text-white">Jingle & Studio Vocal</option>
                    <option value="other" className="bg-slate-900 text-white">Autre projet</option>
                  </select>
                </div>

                <div>
                  <label htmlFor="client-message" className="text-xs font-bold text-slate-400 uppercase tracking-wider block mb-2">
                    Détaillez vos besoins *
                  </label>
                  <textarea
                    id="client-message"
                    required
                    rows={4}
                    value={message}
                    onChange={(e) => setMessage(e.target.value)}
                    placeholder="Quelles fonctionnalités souhaitez-vous ? Avez-vous un cahier des charges ?"
                    className="w-full bg-[#020617]/50 border border-white/10 rounded-xl px-4 py-3.5 text-sm focus:outline-none focus:border-gold placeholder:text-white/20 text-white focus:ring-2 focus:ring-gold/10 transition resize-none h-32"
                  />
                </div>

                <p className="text-[11px] text-slate-500 italic">
                  * En soumettant ce formulaire, vous acceptez d'être contacté par téléphone pour l'élaboration de votre devis.
                </p>

                <button
                  type="submit"
                  className="w-full py-4 rounded-xl font-bold bg-gold hover:bg-gold-light text-white shadow-md hover:shadow-lg transition flex items-center justify-center gap-2 cursor-pointer text-sm font-display uppercase tracking-wider"
                >
                  Envoyer la demande
                  <Send size={15} />
                </button>
              </form>
            ) : (
              <div className="bg-[#1e293b]/50 border border-green-500/20 backdrop-blur-md rounded-3xl p-10 h-full flex flex-col items-center justify-center text-center shadow-xl animate-fadeUp">
                <CheckCircle2 size={48} className="text-[#a5d6a7] mb-4 animate-bounce" />
                <h3 className="font-display font-black text-2xl text-green-300 mb-3">
                  Demande Transmise !
                </h3>
                <p className="text-slate-200 text-sm leading-relaxed max-w-sm mb-8">
                  Merci <strong>{name}</strong> ! Votre message d'entretien technique a été enregistré avec succès. 
                  Notre équipe va analyser votre demande de service et vous contactera au <strong>{phone}</strong> dans les plus brefs délais.
                </p>
                <div className="flex gap-4 w-full max-w-xs">
                  <button
                    onClick={handleReset}
                    className="flex-1 py-3 text-sm font-bold bg-white/5 text-white hover:bg-white/10 rounded-xl transition duration-150 border border-white/10 cursor-pointer"
                  >
                    Nouveau message
                  </button>
                </div>
              </div>
            )}
          </div>
        </div>
      </div>
    </section>
  );
};
