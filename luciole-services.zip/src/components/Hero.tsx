/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 */

import React, { useState, useEffect } from "react";
import { ArrowRight, ChevronLeft, ChevronRight } from "lucide-react";
import {
  TeamIllustration,
  CoderIllustration,
  WebCreationIllustration,
  AudioRecordingIllustration,
} from "./Illustrations";

export const Hero: React.FC = () => {
  const [currentSlide, setCurrentSlide] = useState(0);

  const slides = [
    {
      tag: "Équipe Passionnée",
      title: "Des experts métiers unis pour votre réussite.",
      Illustration: TeamIllustration,
    },
    {
      tag: "Développement sur-mesure",
      title: "Un code propre et structuré pour durer.",
      Illustration: CoderIllustration,
    },
    {
      tag: "Expérience Utilisateur",
      title: "Des sites modernes, ultra-rapides et intuitifs.",
      Illustration: WebCreationIllustration,
    },
    {
      tag: "Production Audiovisuelle",
      title: "Des spots, voix off et jingles d'impact national.",
      Illustration: AudioRecordingIllustration,
    },
  ];

  useEffect(() => {
    const interval = setInterval(() => {
      setCurrentSlide((prev) => (prev + 1) % slides.length);
    }, 6000);
    return () => clearInterval(interval);
  }, [slides.length]);

  return (
    <section
      id="accueil"
      className="relative min-h-[95vh] flex items-center bg-gradient-to-br from-navy-dark via-[#081318] to-black text-white pt-24 overflow-hidden"
    >
      {/* Luciole dynamic particles */}
      <div className="absolute inset-0 pointer-events-none select-none z-1 overflow-hidden">
        {Array.from({ length: 18 }).map((_, i) => {
          const size = Math.random() * 4 + 2;
          const left = Math.random() * 100;
          const delay = Math.random() * 8;
          const duration = Math.random() * 12 + 8;
          return (
            <div
              key={i}
              className="absolute rounded-full bg-gold-light/40 animate-pulse-slow shadow-[0_0_10px_2px_rgba(96,165,250,0.4)]"
              style={{
                width: `${size}px`,
                height: `${size}px`,
                left: `${left}%`,
                bottom: "-20px",
                animation: `float ${duration}s ease-in-out infinite`,
                animationDelay: `${delay}s`,
              }}
            />
          );
        })}
      </div>

      <div className="max-w-7xl mx-auto px-6 grid grid-cols-1 lg:grid-cols-12 gap-12 items-center relative z-10 w-full py-12">
        {/* Left column info text */}
        <div className="lg:col-span-7 flex flex-col items-start text-left">
          <div className="inline-flex items-center gap-2 px-3 py-1.5 rounded-full bg-gold/10 border border-gold/20 mb-6 animate-pulse">
            <span className="w-2 h-2 rounded-full bg-gold animate-ping" />
            <span className="text-xs font-bold text-gold-light uppercase tracking-wider">
              Partenaire Freelance de Confiance • Douala
            </span>
          </div>

          <h1 className="font-display font-black text-4xl sm:text-5xl lg:text-6xl leading-[1.1] tracking-tight mb-6">
            Donnez de l'éclat à vos idées avec{" "}
            <span className="bg-gradient-to-r from-gold via-gold-light to-gold bg-clip-text text-transparent">
              Luciole Services
            </span>
          </h1>

          <p className="text-gray-300 text-lg sm:text-xl leading-relaxed mb-8 max-w-xl">
            Du design de sites vitrines et e-commerce au développement d'applications mobiles,
            conception de bases de données, en passant par de superbes jingles et voix-off
            professionnelles.
          </p>

          <div className="flex flex-wrap gap-4 w-full sm:w-auto">
            <a
              href="#estimator"
              className="px-8 py-4 rounded-xl font-bold bg-gold text-white hover:bg-gold-light transition shadow-lg shadow-gold/25 flex items-center gap-2 group w-full sm:w-auto justify-center"
            >
              Simuler mon tarif
              <ArrowRight size={16} className="transform group-hover:translate-x-1 transition" />
            </a>
            <a
              href="#services"
              className="px-8 py-4 rounded-xl font-bold border-2 border-white/20 hover:border-gold hover:bg-white/5 transition text-white w-full sm:w-auto justify-center text-center inline-block"
            >
              Découvrir nos services
            </a>
          </div>
        </div>

        {/* Right Column illustration carousel */}
        <div className="lg:col-span-5 w-full">
          <div className="relative rounded-2xl overflow-hidden border border-white/10 shadow-2xl shadow-black/60 bg-navy-dark/[0.4] backdrop-blur-md aspect-video sm:aspect-square md:aspect-video lg:aspect-square flex items-center justify-center">
            {slides.map((slide, index) => {
              const ActiveIllustration = slide.Illustration;
              return (
                <div
                  key={index}
                  className={`absolute inset-0 transition-all duration-1000 flex flex-col ${
                    index === currentSlide
                      ? "opacity-100 scale-100 pointer-events-auto"
                      : "opacity-0 scale-95 pointer-events-none"
                  }`}
                >
                  <div className="relative w-full h-[85%]">
                    <ActiveIllustration />
                  </div>
                  <div className="bg-navy-dark/90 p-4 border-t border-white/5 flex items-center justify-between text-left h-[15%]">
                    <div>
                      <span className="text-[10px] font-bold text-gold uppercase tracking-widest">
                        {slide.tag}
                      </span>
                      <h3 className="text-sm font-semibold text-white/95 truncate">
                        {slide.title}
                      </h3>
                    </div>

                    {/* Slides direction trigger */}
                    <div className="flex items-center gap-1.5 shrink-0">
                      <button
                        onClick={() =>
                          setCurrentSlide((prev) => (prev - 1 + slides.length) % slides.length)
                        }
                        className="p-1 rounded-full bg-white/5 hover:bg-white/15 transition cursor-pointer"
                        aria-label="Previous"
                      >
                        <ChevronLeft size={16} />
                      </button>
                      <button
                        onClick={() => setCurrentSlide((prev) => (prev + 1) % slides.length)}
                        className="p-1 rounded-full bg-white/5 hover:bg-white/15 transition cursor-pointer"
                        aria-label="Next"
                      >
                        <ChevronRight size={16} />
                      </button>
                    </div>
                  </div>
                </div>
              );
            })}
          </div>

          {/* Dots tracker bar */}
          <div className="flex items-center justify-center gap-2 mt-4">
            {slides.map((_, i) => (
              <button
                key={i}
                onClick={() => setCurrentSlide(i)}
                className={`h-2 rounded-full transition-all duration-300 ${
                  i === currentSlide ? "w-6 bg-gold" : "w-2 bg-white/30"
                }`}
                aria-label={`Slide ${i + 1}`}
              />
            ))}
          </div>
        </div>
      </div>
    </section>
  );
};
