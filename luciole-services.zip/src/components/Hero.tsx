import React, { useState, useEffect } from "react";
import { ArrowRight, Code, Globe, Volume2, Users, Award } from "lucide-react";

const slides = [
  {
    id: 1,
    image: "https://images.unsplash.com/photo-1531123897727-8f129e1688ce?w=900&q=80",
    tag: "Notre équipe",
    title: "Des sourires et de la passion à chaque projet",
    alt: "Femme africaine souriante au travail",
    icon: <Users className="w-4 h-4 text-amber-500" />
  },
  {
    id: 2,
    image: "https://images.unsplash.com/photo-1573164713988-8665fc963095?w=900&q=80",
    tag: "Développement",
    title: "Un code soigné pour des résultats fiables",
    alt: "Développeur africain concentré sur son code",
    icon: <Code className="w-4 h-4 text-amber-500" />
  },
  {
    id: 3,
    image: "https://images.unsplash.com/photo-1551650975-87deedd944c3?w=900&q=80",
    tag: "Création web",
    title: "Des sites modernes, rapides et élégants",
    alt: "Création de site web professionnel",
    icon: <Globe className="w-4 h-4 text-amber-500" />
  },
  {
    id: 4,
    image: "https://images.unsplash.com/photo-1598488035139-bdbb2231ce04?w=900&q=80",
    tag: "Studio audio",
    title: "Voix off, jingles et spots qui marquent",
    alt: "Studio audio professionnel",
    icon: <Volume2 className="w-4 h-4 text-amber-500" />
  }
];

export default function Hero() {
  const [currentSlide, setCurrentSlide] = useState(0);

  // Auto transition of slides
  useEffect(() => {
    const timer = setInterval(() => {
      setCurrentSlide((prev) => (prev + 1) % slides.length);
    }, 5000);
    return () => clearInterval(timer);
  }, []);

  return (
    <section
      id="accueil"
      className="relative min-h-screen flex items-center pt-24 pb-16 bg-gradient-to-br from-slate-900 via-slate-800 to-indigo-950 text-white overflow-hidden"
    >
      {/* Glow Effects */}
      <div className="absolute inset-0 pointer-events-none z-10">
        <div className="absolute top-[20%] right-[10%] w-[35rem] h-[35rem] rounded-full bg-amber-400/10 filter blur-[120px] animate-pulse duration-5000" />
        <div className="absolute bottom-[10%] left-[5%] w-[25rem] h-[25rem] rounded-full bg-amber-300/5 filter blur-[100px] animate-pulse duration-4000" />
      </div>

      {/* Floating Particles */}
      <div className="absolute inset-0 pointer-events-none z-0 overflow-hidden">
        {Array.from({ length: 15 }).map((_, index) => {
          const style = {
            width: `${Math.random() * 5 + 3}px`,
            height: `${Math.random() * 5 + 3}px`,
            left: `${Math.random() * 100}%`,
            bottom: `-20px`,
            animation: `driftUp ${Math.random() * 12 + 10}s linear infinite`,
            animationDelay: `${Math.random() * 8}s`,
            opacity: Math.random() * 0.4 + 0.2,
          };
          return (
            <div
              key={index}
              style={style}
              className="absolute rounded-full bg-amber-400"
            />
          );
        })}
      </div>

      {/* Custom Keyframe Styles Inline */}
      <style>{`
        @keyframes driftUp {
          from {
            transform: translateY(0) translateX(0);
            opacity: 0;
          }
          10% {
            opacity: 0.5;
          }
          90% {
            opacity: 0.3;
          }
          to {
            transform: translateY(-110vh) translateX(40px);
            opacity: 0;
          }
        }
      `}</style>

      <div className="max-w-7xl mx-auto px-6 w-full relative z-20">
        <div className="grid grid-cols-1 lg:grid-cols-12 gap-12 items-center">
          {/* Main Hero Text */}
          <div className="lg:col-span-7 flex flex-col justify-center text-left">
            <span className="inline-flex items-center gap-2 bg-amber-400/15 border border-amber-400/30 text-amber-300 font-semibold text-xs tracking-wider uppercase px-4 py-1.5 rounded-md mb-6 w-max">
              <Award className="w-3.5 h-3.5 text-amber-400" />
              Agence digitale &amp; audiovisuelle
            </span>

            <h1 className="font-display font-extrabold text-4xl sm:text-5xl lg:text-6xl text-white leading-tight mb-6">
              Donnez vie à vos idées avec{" "}
              <span className="text-transparent bg-clip-text bg-gradient-to-r from-amber-400 via-amber-250 to-amber-500 bg-[length:200%_auto] animate-[shineEffect_4s_linear_infinite] underline decoration-amber-400/40 underline-offset-4">
                Luciole-services
              </span>
            </h1>

            <p className="text-base sm:text-lg text-slate-300 max-w-xl leading-relaxed mb-8 italic">
              Sites web modernes, applications mobiles intuitives, architectures de bases de données sécurisées et productions audiovisuelles d'exception. Nous sommes votre partenaire stratégique pour briller sur tous vos écrans.
            </p>

            <div className="flex flex-wrap gap-4">
              <a
                href="#contact"
                className="bg-amber-400 hover:bg-white text-slate-900 font-bold px-8 py-4 rounded-lg transition-all duration-300 transform hover:-translate-y-1 inline-flex items-center gap-2 shadow-lg shadow-amber-400/20 animate-bounce"
                style={{ animation: "pulseGlow 2.6s infinite" }}
              >
                Demander un devis <ArrowRight className="w-4 h-4" />
              </a>
              <a
                href="#services"
                className="px-8 py-4 bg-white/10 text-white font-bold rounded-lg border border-white/20 hover:border-amber-400 hover:bg-white/15 transition-all duration-300 transform hover:-translate-y-1 inline-flex items-center"
              >
                Voir nos services
              </a>
            </div>

            <p className="text-xs text-amber-400 mt-4 font-semibold tracking-wide flex items-center gap-2 animate-pulse bg-amber-400/5 px-3 py-2 rounded-lg border border-amber-400/20 w-max max-w-full">
              <span className="w-2 h-2 rounded-full bg-amber-400 shrink-0"></span>
              Profitez d'un premier chiffrage 100% gratuit en moins de 24h ! Cliquez sur le bouton ci-dessus pour simuler vos besoins.
            </p>
          </div>

          {/* Interactive Slideshow Visual */}
          <div className="lg:col-span-5">
            <div className="relative h-[400px] sm:h-[450px] rounded-2xl overflow-hidden shadow-2xl border border-white/10 group">
              {/* Slides */}
              {slides.map((slide, idx) => (
                <div
                  key={slide.id}
                  className={`absolute inset-0 transition-opacity duration-1000 ease-in-out ${
                    idx === currentSlide ? "opacity-100 z-10" : "opacity-0 z-0"
                  }`}
                >
                  <img
                    src={slide.image}
                    alt={slide.alt}
                    className="w-full h-full object-cover transform scale-105 transition-transform duration-10000 ease-out group-hover:scale-110"
                  />
                  {/* Overlay */}
                  <div className="absolute inset-0 bg-gradient-to-t from-slate-950 via-transparent to-transparent opacity-85" />

                  {/* Caption */}
                  <div className="absolute bottom-6 left-6 right-6 z-20">
                    <span className="inline-flex items-center gap-1.5 bg-amber-400 text-slate-900 font-bold text-xs uppercase px-3 py-1 rounded-md mb-2 tracking-wide">
                      {slide.icon}
                      {slide.tag}
                    </span>
                    <h4 className="text-xl font-display font-bold text-white leading-normal">
                      {slide.title}
                    </h4>
                  </div>
                </div>
              ))}

              {/* Slider Dots */}
              <div className="absolute top-6 right-6 flex gap-2 z-30">
                {slides.map((_, idx) => (
                  <button
                    key={idx}
                    onClick={() => setCurrentSlide(idx)}
                    className={`h-2 rounded-full cursor-pointer transition-all duration-300 ${
                      idx === currentSlide ? "bg-amber-400 w-6" : "bg-white/45 w-2"
                    }`}
                    aria-label={`Aller au slide ${idx + 1}`}
                  />
                ))}
              </div>
            </div>
          </div>
        </div>
      </div>
    </section>
  );
}
