/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 */

import React from "react";
import { ArrowUp } from "lucide-react";

export const Footer: React.FC = () => {
  const scrollToTop = () => {
    window.scrollTo({ top: 0, behavior: "smooth" });
  };

  return (
    <footer className="bg-transparent text-slate-400 py-16 border-t border-white/5 relative z-30">
      <div className="max-w-7xl mx-auto px-6">
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-12 mb-16">
          {/* Column 1 Logo details */}
          <div className="flex flex-col items-start">
            <span className="font-display font-black text-2xl text-white mb-4">
              Luciole<span className="text-gold"> Services</span>
            </span>
            <p className="text-sm text-slate-400 mb-6 leading-relaxed max-w-xs">
              Votre agence freelance premium pour la création de sites internet, d'applications mobiles, bases de données, et l'enregistrement de voix off professionnelles à Douala.
            </p>
            <div className="flex items-center gap-3">
              <span className="px-2.5 py-1 text-[10px] font-bold uppercase tracking-widest text-gold bg-gold/5 border border-gold/10 rounded">
                Douala, Cameroun
              </span>
            </div>
          </div>

          {/* Column 2 Services */}
          <div>
            <h4 className="font-display font-bold text-sm text-white uppercase tracking-wider mb-6">
              Nos Services
            </h4>
            <ul className="flex flex-col gap-3 list-none m-0 p-0">
              <li>
                <a href="#services" className="text-sm hover:text-gold transition">
                  Création de sites web
                </a>
              </li>
              <li>
                <a href="#services" className="text-sm hover:text-gold transition">
                  Applications mobiles
                </a>
              </li>
              <li>
                <a href="#services" className="text-sm hover:text-gold transition">
                  Bases de données SQL
                </a>
              </li>
              <li>
                <a href="#vocal-studio" className="text-sm hover:text-gold transition">
                  Studio Voix off & Jingles
                </a>
              </li>
            </ul>
          </div>

          {/* Column 3 Links */}
          <div>
            <h4 className="font-display font-bold text-sm text-white uppercase tracking-wider mb-6">
              Plan du site
            </h4>
            <ul className="flex flex-col gap-3 list-none m-0 p-0">
              <li>
                <a href="#accueil" className="text-sm hover:text-gold transition">
                  Page d'accueil
                </a>
              </li>
              <li>
                <a href="#realisations" className="text-sm hover:text-gold transition">
                  Réalisations & Portfolio
                </a>
              </li>
              <li>
                <a href="#estimator" className="text-sm hover:text-gold transition">
                  Calculateur de budget
                </a>
              </li>
              <li>
                <a href="#contact" className="text-sm hover:text-gold transition">
                  Nous Contacter
                </a>
              </li>
            </ul>
          </div>

          {/* Column 4 Context references */}
          <div>
            <h4 className="font-display font-bold text-sm text-white uppercase tracking-wider mb-6">
              Coordonnées
            </h4>
            <ul className="flex flex-col gap-3 list-none m-0 p-0 text-sm leading-relaxed text-gray-400">
              <li>Douala, Cameroun</li>
              <li>+237 699 95 80 89 (WhatsApp & Tel)</li>
              <li>luciole@services.com</li>
              <li>Disponible du Lundi au Samedi (8h - 19h)</li>
            </ul>
          </div>
        </div>

        {/* Footer bottom */}
        <div className="border-t border-white/5 pt-8 flex flex-col sm:flex-row items-center justify-between gap-4">
          <p className="text-xs text-gray-500 text-center sm:text-left leading-normal">
            © 2026 Luciole Services. Tous droits réservés. Hébergé de manière sécurisée et optimisée.
          </p>

          <button
            onClick={scrollToTop}
            className="p-3 bg-navy hover:bg-gold text-gold hover:text-navy-dark rounded-xl border border-white/5 hover:border-gold shadow-lg transition-all duration-200 cursor-pointer flex items-center justify-center"
            aria-label="Back to top"
          >
            <ArrowUp size={16} />
          </button>
        </div>
      </div>
    </footer>
  );
};
