import React from "react";
import { Facebook, Instagram, Shield, HelpCircle, FileText } from "lucide-react";
import Logo from "./Logo";

export default function Footer() {
  return (
    <footer className="bg-slate-950 text-slate-400 pt-16 pb-8 transition-colors duration-300 border-t border-slate-900">
      <div className="max-w-7xl mx-auto px-6">
        <div className="grid grid-cols-1 md:grid-cols-4 gap-12 pb-12 border-b border-white/5">
          <div>
            {/* Logo */}
            <div className="flex items-center gap-2 mb-4">
              <Logo className="w-9 h-9 text-amber-400" color="currentColor" />
              <span className="font-display font-bold text-xl text-white tracking-tight underline underline-offset-4 decoration-amber-400">
                LUCIOLE SERVICES
              </span>
            </div>
            <p className="text-sm leading-relaxed mb-6 italic">
              Votre partenaire digital d'excellence pour la création de projets web, mobiles et d'identités audiovisuelles qui marquent les esprits.
            </p>
          </div>

          <div>
            <h4 className="text-white font-display font-semibold mb-5 text-sm uppercase tracking-wider">Services</h4>
            <ul className="space-y-3 p-0 list-none m-0">
              <li>
                <a href="#services" className="hover:text-amber-400 transition-all duration-200 hover:pl-1 text-sm block">
                  Création Sites Web
                </a>
              </li>
              <li>
                <a href="#services" className="hover:text-amber-400 transition-all duration-200 hover:pl-1 text-sm block">
                  Applications Mobiles
                </a>
              </li>
              <li>
                <a href="#services" className="hover:text-amber-400 transition-all duration-200 hover:pl-1 text-sm block">
                  Bases de Données
                </a>
              </li>
              <li>
                <a href="#audiovisuel" className="hover:text-amber-400 transition-all duration-200 hover:pl-1 text-sm block">
                  Audio &amp; Vidéo
                </a>
              </li>
            </ul>
          </div>

          <div>
            <h4 className="text-white font-display font-semibold mb-5 text-sm uppercase tracking-wider">Liens utiles</h4>
            <ul className="space-y-3 p-0 list-none m-0">
              <li>
                <a href="#accueil" className="hover:text-amber-400 transition-all duration-200 hover:pl-1 text-sm block">
                  Accueil
                </a>
              </li>
              <li>
                <a href="#realisations" className="hover:text-amber-400 transition-all duration-200 hover:pl-1 text-sm block">
                  Réalisations
                </a>
              </li>
              <li>
                <a href="#apropos" className="hover:text-amber-400 transition-all duration-200 hover:pl-1 text-sm block">
                  À propos
                </a>
              </li>
              <li>
                <a href="#contact" className="hover:text-amber-400 transition-all duration-200 hover:pl-1 text-sm block">
                  Contact
                </a>
              </li>
            </ul>
          </div>

          <div>
            <h4 className="text-white font-display font-semibold mb-5 text-sm uppercase tracking-wider">Contact</h4>
            <ul className="space-y-3 text-sm p-0 list-none m-0">
              <li className="flex items-center gap-2">
                <span className="text-amber-400">📞</span>
                <span>+237 699 95 80 89</span>
              </li>
              <li className="flex items-center gap-2">
                <span className="text-amber-400">✉️</span>
                <span>divis@luciole-serves.com</span>
              </li>
              <li className="flex items-center gap-2">
                <span className="text-amber-400">📍</span>
                <span>Douala, Cameroun</span>
              </li>
            </ul>
          </div>
        </div>

        <div className="pt-8 flex flex-col md:flex-row items-center justify-between gap-4 text-xs">
          <p>© 2026 Luciole-services. Tous droits réservés.</p>
          
          {/* Social Icons requested by User */}
          <div className="flex items-center gap-5">
            <a 
              href="https://www.facebook.com/share/1AWzpnveXJ/" 
              target="_blank" 
              rel="noopener noreferrer"
              aria-label="Facebook Luciole Services"
              className="w-10 h-10 rounded-full bg-white/5 hover:bg-[#1877F2] text-slate-400 hover:text-white flex items-center justify-center transition-all duration-300 hover:scale-110 shadow-lg hover:shadow-[#1877F2]/20"
            >
              <Facebook className="w-5 h-5" />
            </a>
            
            <a 
              href="https://www.instagram.com/lucioleservices?igsh=dzZwdGM4MmJwZHE4" 
              target="_blank" 
              rel="noopener noreferrer"
              aria-label="Instagram Luciole Services"
              className="w-10 h-10 rounded-full bg-white/5 hover:bg-gradient-to-tr hover:from-[#F58529] hover:via-[#DD2A7B] hover:to-[#8134AF] text-slate-400 hover:text-white flex items-center justify-center transition-all duration-300 hover:scale-110 shadow-lg hover:shadow-[#DD2A7B]/20"
            >
              <Instagram className="w-5 h-5" />
            </a>
          </div>
        </div>
      </div>
    </footer>
  );
}
