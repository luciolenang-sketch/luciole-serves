/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 */

import React, { useState, useEffect } from "react";
import { Menu, X, ArrowRight } from "lucide-react";

interface NavbarProps {
  onContactClick: () => void;
}

export const Navbar: React.FC<NavbarProps> = ({ onContactClick }) => {
  const [isOpen, setIsOpen] = useState(false);
  const [scrolled, setScrolled] = useState(false);

  useEffect(() => {
    const handleScroll = () => {
      setScrolled(window.scrollY > 20);
    };
    window.addEventListener("scroll", handleScroll);
    return () => window.removeEventListener("scroll", handleScroll);
  }, []);

  return (
    <header
      className={`fixed top-0 left-0 right-0 z-50 transition-all duration-300 ${
        scrolled
          ? "bg-[#020617]/85 backdrop-blur-md border-b border-[#1e293b] shadow-xl py-3 text-white"
          : "bg-navy-dark/90 backdrop-blur-sm border-b border-white/5 py-4 text-white"
      }`}
    >
      <div className="max-w-7xl mx-auto px-6 flex items-center justify-between">
        {/* Logo Custom brand */}
        <a href="#accueil" className="flex items-center gap-2">
          <div className="relative flex items-center justify-center w-10 h-10 rounded-full bg-gradient-to-tr from-gold to-gold-light">
            <span className="font-display font-black text-white text-lg">L</span>
            <div className="absolute -inset-1 bg-gold/30 rounded-full blur animate-ping opacity-30" />
          </div>
          <div className="flex flex-col">
            <span className="font-display font-extrabold text-lg leading-none tracking-tight">
              Luciole
            </span>
            <span className="font-display font-medium text-[10px] tracking-widest text-gold uppercase leading-normal">
              Services
            </span>
          </div>
        </a>

        {/* Navigation Items - Desktop */}
        <nav className="hidden md:flex items-center gap-8">
          <ul className="flex items-center gap-8 list-none m-0 p-0">
            {[
              { label: "Accueil", href: "#accueil" },
              { label: "Services", href: "#services" },
              { label: "Réalisations", href: "#realisations" },
              { label: "Studio Audio", href: "#vocal-studio" },
              { label: "Simulateur", href: "#estimator" },
              { label: "À propos", href: "#apropos" },
            ].map((link) => (
              <li key={link.href}>
                <a
                  href={link.href}
                  className="font-semibold text-sm transition-colors duration-200 relative py-1 after:absolute after:bottom-0 after:left-0 after:w-0 after:h-[2px] after:bg-gold after:transition-all after:duration-300 hover:after:w-full text-white/90 hover:text-gold-light"
                >
                  {link.label}
                </a>
              </li>
            ))}
          </ul>
        </nav>

        {/* CTA action */}
        <div className="hidden md:flex items-center">
          <button
            onClick={onContactClick}
            className="flex items-center gap-2 px-5 py-2.5 rounded-full text-xs font-bold uppercase tracking-wider bg-gold hover:bg-gold-light text-white shadow-lg shadow-gold/25 cursor-pointer transform hover:-translate-y-0.5 transition"
          >
            Nouveau Projet
            <ArrowRight size={13} />
          </button>
        </div>

        {/* Mobile menu trigger */}
        <button
          onClick={() => setIsOpen(!isOpen)}
          className="md:hidden p-2 rounded-lg transition-colors text-white hover:bg-white/5"
          aria-label="Menu"
        >
          {isOpen ? <X size={24} /> : <Menu size={24} />}
        </button>
      </div>

      {/* Mobile nav drawer */}
      {isOpen && (
        <div className="md:hidden absolute top-full left-0 right-0 bg-[#020617]/95 backdrop-blur-lg border-b border-[#1e293b] shadow-2xl z-50 animate-fadeUp">
          <nav className="flex flex-col p-6 gap-4">
            {[
              { label: "Accueil", href: "#accueil" },
              { label: "Services", href: "#services" },
              { label: "Réalisations", href: "#realisations" },
              { label: "Studio Audio", href: "#vocal-studio" },
              { label: "Simulateur Budget", href: "#estimator" },
              { label: "À propos", href: "#apropos" },
              { label: "Contact", href: "#contact" },
            ].map((link) => (
              <a
                key={link.href}
                href={link.href}
                onClick={() => setIsOpen(false)}
                className="font-bold text-base text-white/95 hover:text-gold py-2 border-b border-[#1e293b] transition-colors"
              >
                {link.label}
              </a>
            ))}
            <button
              onClick={() => {
                setIsOpen(false);
                onContactClick();
              }}
              className="mt-2 w-full flex items-center justify-center gap-2 py-3 bg-gold hover:bg-gold-light text-white font-extrabold rounded-xl transition"
            >
              Démarrer un projet
              <ArrowRight size={16} />
            </button>
          </nav>
        </div>
      )}
    </header>
  );
};
