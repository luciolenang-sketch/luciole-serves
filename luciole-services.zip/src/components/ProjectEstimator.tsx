/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 */

import React, { useState, useMemo } from "react";
import { formatCurrency } from "../utils";
import { Calculator, ArrowRight, MessageSquare, ShieldCheck, CheckCircle } from "lucide-react";

type ProjectType = "vitrine" | "ecommerce" | "mobile" | "design" | "pub-spot";

export const ProjectEstimator: React.FC = () => {
  const [projectType, setProjectType] = useState<ProjectType>("vitrine");
  const [languages, setLanguages] = useState<number>(1);
  const [supportMonths, setSupportMonths] = useState<number>(3);
  const [hasVoiceOff, setHasVoiceOff] = useState<boolean>(false);
  const [hasJingle, setHasJingle] = useState<boolean>(false);
  const [currency, setCurrency] = useState<"EUR" | "XAF">("XAF");

  // Custom pricing matrix (in XAF / we map to EUR at fixed exchange rate 655.957)
  const basePrices: Record<ProjectType, number> = {
    vitrine: 250000,   // ~380 EUR
    ecommerce: 500000, // ~760 EUR
    mobile: 900000,    // ~1370 EUR
    "pub-spot": 150000,  // ~230 EUR
    design: 100000,    // ~150 EUR
  };

  const calculatedTotal = useMemo(() => {
    let priceXaf = basePrices[projectType];

    // Language multiplier
    if (languages > 1) {
      priceXaf += (languages - 1) * 60000;
    }

    // Support duration pricing
    if (supportMonths === 3) priceXaf += 45000;
    if (supportMonths === 12) priceXaf += 150000;

    // Optional Audio packs
    if (hasVoiceOff) priceXaf += 75000;
    if (hasJingle) priceXaf += 50000;

    return priceXaf;
  }, [projectType, languages, supportMonths, hasVoiceOff, hasJingle]);

  const outputTotal = useMemo(() => {
    if (currency === "EUR") {
      return calculatedTotal / 655.957; // CFA franc is pegged strictly to Euro at 655.957
    }
    return calculatedTotal;
  }, [calculatedTotal, currency]);

  // Generate dynamic Whatsapp link composition
  const handleOrderWhatsApp = () => {
    const space = "%20";
    const line = "%0A";
    const projectLabel: Record<ProjectType, string> = {
      vitrine: "Site Vitrine",
      ecommerce: "Site E-Commerce",
      mobile: "Application Mobile (iOS/Android)",
      design: "Design Graphique & Logo",
      "pub-spot": "Spot Publicitaire & Audiovisuel",
    };

    const text = `Bonjour Luciole Services ! 👋${line}${line}` +
      `Je viens de simuler un projet sur votre site internet et j'aimerais commander un devis officiel.${line}${line}` +
      `📋 *DÉTAILS DU PROJET* :${line}` +
      `• *Type de Projet* : ${projectLabel[projectType]}${line}` +
      `• *Langues requises* : ${languages}${line}` +
      `• *Maintenance Technique* : ${supportMonths === 0 ? "Sans option" : `${supportMonths} mois`}${line}` +
      `• *Option Voix-Off* : ${hasVoiceOff ? "Oui" : "Non"}${line}` +
      `• *Option Jingle Audio* : ${hasJingle ? "Oui" : "Non"}${line}${line}` +
      `💰 *Estimation Tarifaire* : ~${formatCurrency(outputTotal, currency)}${line}${line}` +
      `Merci de me recontacter pour lancer le cahier des charges !`;

    const cleanLink = `https://wa.me/237699958089?text=${text}`;
    window.open(cleanLink, "_blank");
  };

  return (
    <section id="estimator" className="py-24 bg-transparent text-slate-100 relative z-30">
      <div className="max-w-7xl mx-auto px-6">
        {/* Header section info */}
        <div className="text-center max-w-3xl mx-auto mb-16">
          <span className="text-gold font-bold uppercase tracking-[0.2em] text-xs block mb-3">
            Estimateur de budget transparent
          </span>
          <h2 className="font-display font-black text-3xl sm:text-4xl text-white leading-tight mb-4">
            Simulez votre projet en 15 secondes.
          </h2>
          <p className="text-slate-400 text-lg leading-relaxed">
            Configurez vos options selon vos ambitions digitales et obtenez un coût d'estimation estimatif en temps réel, 100% transparent.
          </p>
        </div>

        {/* Panel layouts */}
        <div className="grid grid-cols-1 lg:grid-cols-12 gap-12 bg-[#1e293b]/30 backdrop-blur-md rounded-3xl p-6 sm:p-10 border border-white/5 shadow-xl items-stretch">
          {/* Left panel features selection */}
          <div className="lg:col-span-7 flex flex-col gap-6">
            <h3 className="font-display font-bold text-lg text-white flex items-center gap-2 mb-2">
              <Calculator size={18} className="text-gold" />
              Configurez vos besoins de service :
            </h3>

            {/* Currency selectors */}
            <div>
              <span className="text-xs font-bold text-slate-500 uppercase tracking-wider block mb-2">
                Devise d'affichage
              </span>
              <div className="flex gap-2">
                <button
                  onClick={() => setCurrency("XAF")}
                  className={`px-4 py-2 text-xs font-bold rounded-lg border cursor-pointer transition ${
                    currency === "XAF"
                      ? "bg-gold border-gold text-white"
                      : "bg-white/5 text-slate-300 border-white/10 hover:border-gold/30 hover:bg-white/10"
                  }`}
                >
                  Franc CFA (XAF) - Cameroun
                </button>
                <button
                  onClick={() => setCurrency("EUR")}
                  className={`px-4 py-2 text-xs font-bold rounded-lg border cursor-pointer transition ${
                    currency === "EUR"
                      ? "bg-gold border-gold text-white"
                      : "bg-white/5 text-slate-300 border-white/10 hover:border-gold/30 hover:bg-white/10"
                  }`}
                >
                  Euro (€) - International
                </button>
              </div>
            </div>

            {/* Type of project choice */}
            <div>
              <span className="text-xs font-bold text-slate-500 uppercase tracking-wider block mb-2">
                1. Nature du Projet
              </span>
              <div className="grid grid-cols-1 sm:grid-cols-2 gap-3">
                {[
                  { id: "vitrine", label: "💻 Site Web Vitrine" },
                  { id: "ecommerce", label: "🛒 Boutique E-Commerce" },
                  { id: "mobile", label: "⚡ App Mobile iOS / Android" },
                  { id: "pub-spot", label: "🎬 Spot Publicitaire Audiovisuel" },
                  { id: "design", label: "🎨 Logo / Identité Visuelle" },
                ].map((type) => (
                  <button
                    key={type.id}
                    onClick={() => setProjectType(type.id as ProjectType)}
                    className={`p-4 rounded-xl font-semibold text-sm text-left border cursor-pointer transition-all ${
                      projectType === type.id
                        ? "bg-gold/15 text-white border-gold font-bold shadow-sm"
                        : "bg-[#020617]/40 text-slate-300 border-white/5 hover:border-white/20 hover:bg-white/10"
                    }`}
                  >
                    {type.label}
                  </button>
                ))}
              </div>
            </div>

            {/* Language numbers input */}
            <div>
              <div className="flex justify-between items-center mb-2">
                <label htmlFor="languages-select" className="text-xs font-bold text-slate-500 uppercase tracking-wider">
                  2. Nombre de langues ({languages})
                </label>
                <span className="text-[11px] text-slate-500 font-semibold">* Multilinguisme Google SEO</span>
              </div>
              <div className="flex items-center gap-2">
                {[1, 2, 3].map((num) => (
                  <button
                    key={num}
                    onClick={() => setLanguages(num)}
                    className={`w-12 h-12 rounded-xl text-sm font-bold border cursor-pointer transition ${
                      languages === num
                        ? "bg-gold text-white border-gold shadow-sm"
                        : "bg-white/5 text-slate-300 border-white/5 hover:border-white/20 hover:bg-white/10"
                    }`}
                  >
                    {num === 3 ? "3+" : num}
                  </button>
                ))}
              </div>
            </div>

            {/* Support durations checkbox */}
            <div>
              <span className="text-xs font-bold text-slate-500 uppercase tracking-wider block mb-2">
                3. Maintenance, Support & Sauvegardes
              </span>
              <div className="flex flex-wrap gap-2">
                {[
                  { value: 0, label: "Sans assistance" },
                  { value: 3, label: "3 Mois pro (Inclus)" },
                  { value: 12, label: "12 Mois sérénité" },
                ].map((opt) => (
                  <button
                    key={opt.value}
                    onClick={() => setSupportMonths(opt.value)}
                    className={`px-5 py-3 rounded-xl text-xs font-semibold border cursor-pointer transition ${
                      supportMonths === opt.value
                        ? "bg-gold border-gold text-white shadow-sm"
                        : "bg-white/5 text-slate-300 border-white/5 hover:border-white/25 hover:bg-white/10"
                    }`}
                  >
                    {opt.label}
                  </button>
                ))}
              </div>
            </div>

            {/* Optional packs trigger */}
            <div className="flex flex-col gap-3">
              <span className="text-xs font-bold text-slate-500 uppercase tracking-wider block">
                4. Options Audio & Studio additionnelles
              </span>
              <div className="flex flex-col sm:flex-row gap-3">
                <button
                  type="button"
                  onClick={() => setHasVoiceOff(!hasVoiceOff)}
                  className={`flex-1 p-4 rounded-xl border text-sm text-left font-semibold cursor-pointer flex items-center justify-between transition ${
                    hasVoiceOff ? "bg-gold/15 text-white border-gold shadow-sm" : "bg-white/5 border-white/5 text-slate-300 hover:border-white/20"
                  }`}
                >
                  <span>🎤 Ajouter une Voix Off Studio</span>
                  <input
                    type="checkbox"
                    checked={hasVoiceOff}
                    onChange={() => {}}
                    className="accent-gold w-4 h-4 cursor-pointer"
                  />
                </button>

                <button
                  type="button"
                  onClick={() => setHasJingle(!hasJingle)}
                  className={`flex-1 p-4 rounded-xl border text-sm text-left font-semibold cursor-pointer flex items-center justify-between transition ${
                    hasJingle ? "bg-gold/15 text-white border-gold shadow-sm" : "bg-white/5 border-white/5 text-slate-300 hover:border-white/20"
                  }`}
                >
                  <span>🎵 Signature sonore Brand Jingle</span>
                  <input
                    type="checkbox"
                    checked={hasJingle}
                    onChange={() => {}}
                    className="accent-gold w-4 h-4 cursor-pointer"
                  />
                </button>
              </div>
            </div>
          </div>

          {/* Right panel pricing billing calculator */}
          <div className="lg:col-span-5 bg-[#0f172a] text-white rounded-2xl p-6 sm:p-8 flex flex-col justify-between border border-white/10 relative overflow-hidden shadow-2xl">
            <div className="absolute top-0 right-0 w-32 h-32 bg-gold/5 rounded-full blur-2xl flex" />

            <div>
              <h4 className="font-display font-medium text-xs text-gold uppercase tracking-widest mb-4">
                Votre Plan Estimatif
              </h4>

              <div className="space-y-4 mb-8">
                {/* Visual bullet check progress */}
                {[
                  "Design UI/UX 100% personnalisé",
                  "Optimisation performance Google PageSpeed",
                  "Sauvegardes quotidiennes",
                  "Code source remis en fin de projet",
                ].map((bullet, idx) => (
                  <div key={idx} className="flex items-center gap-3">
                    <CheckCircle className="text-gold shrink-0" size={16} />
                    <span className="text-xs text-slate-300 font-medium">{bullet}</span>
                  </div>
                ))}
              </div>

              {/* Display dynamic price sum */}
              <div className="bg-white/5 p-6 rounded-2xl border border-white/10 mb-6 text-center">
                <span className="text-[10px] text-slate-400 font-bold uppercase tracking-widest block mb-2">
                  Budget estimatif global
                </span>
                <span className="font-display font-black text-3xl sm:text-4xl text-gold-light tracking-tight leading-none block">
                  {formatCurrency(outputTotal, currency)}
                </span>
                <span className="text-[10px] text-slate-500 font-semibold block mt-2">
                  *Taxes & hébergement d'infrastructure par an inclus
                </span>
              </div>
            </div>

            {/* Actions triggers dispatch */}
            <div className="flex flex-col gap-3">
              <button
                onClick={handleOrderWhatsApp}
                className="w-full py-4 rounded-xl font-bold bg-gold text-white hover:bg-gold-light transition shadow-lg shadow-gold/25 flex items-center justify-center gap-2 group cursor-pointer text-sm"
              >
                Commander via WhatsApp
                <MessageSquare size={16} />
              </button>

              <div className="flex items-center justify-center gap-2 text-[10px] text-slate-400">
                <ShieldCheck size={14} className="text-gold" />
                <span>Devis final envoyé sous 24h ouvrées.</span>
              </div>
            </div>
          </div>
        </div>
      </div>
    </section>
  );
};
