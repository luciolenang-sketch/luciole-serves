/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 */

import React, { useState, useEffect } from "react";
import { Coffee, Award, Smile, CheckCircle, ChevronRight } from "lucide-react";

export const AboutAndCounter: React.FC = () => {
  const [projets, setProjets] = useState(0);
  const [clients, setClients] = useState(0);
  const [domaines, setDomaines] = useState(0);

  useEffect(() => {
    // Dynamic progressive animation on load
    const countTo = (target: number, setter: React.Dispatch<React.SetStateAction<number>>, duration: number) => {
      let cur = 0;
      const step = Math.ceil(target / (duration / 16));
      const timer = setInterval(() => {
        cur += step;
        if (cur >= target) {
          setter(target);
          clearInterval(timer);
        } else {
          setter(cur);
        }
      }, 16);
    };

    countTo(50, setProjets, 1500);
    countTo(30, setClients, 1500);
    countTo(8, setDomaines, 1500);
  }, []);

  return (
    <section id="apropos" className="py-24 bg-transparent text-slate-100 relative overflow-hidden">
      <div className="max-w-7xl mx-auto px-6">
        <div className="grid grid-cols-1 lg:grid-cols-12 gap-12 items-center">
          {/* Left panel company descriptions */}
          <div className="lg:col-span-7">
            <span className="text-gold font-bold uppercase tracking-[0.2em] text-xs block mb-3">
              Qui sommes-nous ?
            </span>
            <h2 className="font-display font-black text-3xl sm:text-4xl text-white leading-tight mb-6">
              L'agilité d'un comète freelance, la rigueur d'une agence premium.
            </h2>

            <p className="text-slate-400 text-base leading-relaxed mb-4">
              Créé en 2026 à Douala, Cameroun, <strong>Luciole Services</strong> est un collectif d'ingénieurs et d'artistes dirigé de manière agile pour vous offrir le meilleur des mondes : des compétences pointues et un interlocuteur unique et disponible en permanence sur WhatsApp.
            </p>
            <p className="text-slate-400 text-base leading-relaxed mb-6">
              Pas de réunions interminables ou de devis gonflés arbitrairement. Nous mettons directement notre savoir-faire au service de votre croissance, avec des cycles de livraison courts et une transparence financière absolue.
            </p>

            {/* Structured workflow list items */}
            <div className="grid grid-cols-1 sm:grid-cols-2 gap-4 mb-8">
              {[
                "Échanges directs et conviviaux par WhatsApp",
                "Maquettes Figma interactives avant codage",
                "Rapports de performance Google Lighthouse",
                "Livraison en 7 à 15 jours ouvrés",
              ].map((value, index) => (
                <div key={index} className="flex items-center gap-3">
                  <div className="p-1 rounded-full bg-gold/15 text-gold shrink-0">
                    <CheckCircle size={14} />
                  </div>
                  <span className="text-sm font-semibold text-white/90 leading-none">
                    {value}
                  </span>
                </div>
              ))}
            </div>

            <a
              href="#contact"
              className="inline-flex items-center gap-1.5 font-bold text-sm text-gold hover:text-gold-light group transition duration-200"
            >
              Envoyer une demande d'entretien technique
              <ChevronRight size={16} className="transform group-hover:translate-x-1 transition" />
            </a>
          </div>

          {/* Right panel graphic metric cards */}
          <div className="lg:col-span-5 grid grid-cols-1 sm:grid-cols-2 gap-6">
            <div className="bg-[#1e293b]/30 backdrop-blur-md rounded-2xl p-6 text-white border border-white/5 relative overflow-hidden flex flex-col justify-between aspect-square hover:border-gold/30 hover:shadow-xl transition duration-300">
              <Award className="text-gold mb-4" size={28} />
              <div>
                <span className="font-display font-black text-5xl text-gold-light tracking-tight leading-none block">
                  {projets}+
                </span>
                <span className="text-xs font-semibold text-slate-400 block mt-2">
                  Projets digitaux et audiovisuels conclus avec brio
                </span>
              </div>
            </div>

            <div className="bg-[#1e293b]/30 backdrop-blur-md rounded-2xl p-6 border border-white/5 shadow-xl flex flex-col justify-between aspect-square hover:border-gold/30 hover:shadow-xl transition duration-300">
              <Smile className="text-gold mb-4" size={28} />
              <div>
                <span className="font-display font-black text-5xl text-white tracking-tight leading-none block">
                  {clients}+
                </span>
                <span className="text-xs font-semibold text-slate-400 block mt-2">
                  Clients de confiance totalement satisfaits
                </span>
              </div>
            </div>

            <div className="bg-[#1e293b]/30 backdrop-blur-md rounded-2xl p-6 border border-white/5 shadow-xl col-span-1 sm:col-span-2 relative overflow-hidden flex items-center justify-between gap-6 hover:border-gold/30 hover:shadow-xl transition duration-300">
              <div className="flex items-center gap-4">
                <Coffee className="text-gold" size={28} />
                <div>
                  <span className="font-display font-black text-3xl text-white leading-none block">
                    {domaines}+
                  </span>
                  <span className="text-xs font-semibold text-slate-400 block mt-1">
                    Spécialités de services et d'intégrations de bases de données
                  </span>
                </div>
              </div>
            </div>
          </div>
        </div>
      </div>
    </section>
  );
};
