import React, { useState, useEffect, useRef } from "react";
import { Users, Award } from "lucide-react";

export default function AboutSection() {
  const [counts, setCounts] = useState({ projects: 0, clients: 0, skills: 0 });
  const sectionRef = useRef<HTMLElement>(null);
  const animatedRef = useRef(false);

  useEffect(() => {
    const observer = new IntersectionObserver(
      (entries) => {
        const entry = entries[0];
        if (entry.isIntersecting && !animatedRef.current) {
          animatedRef.current = true;
          
          const duration = 2000; // ms
          const startTime = performance.now();
          
          const animate = (now: number) => {
            const elapsed = now - startTime;
            const progress = Math.min(elapsed / duration, 1);
            
            // Easing out quadratic
            const easeProgress = progress * (2 - progress);

            setCounts({
              projects: Math.floor(easeProgress * 50),
              clients: Math.floor(easeProgress * 30),
              skills: Math.floor(easeProgress * 5)
            });

            if (progress < 1) {
              requestAnimationFrame(animate);
            } else {
              setCounts({ projects: 50, clients: 30, skills: 5 });
            }
          };

          requestAnimationFrame(animate);
        }
      },
      { threshold: 0.2 }
    );

    if (sectionRef.current) {
      observer.observe(sectionRef.current);
    }

    return () => {
      observer.disconnect();
    };
  }, []);

  return (
    <section id="apropos" ref={sectionRef} className="py-24 bg-white overflow-hidden border-t border-slate-100">
      <div className="max-w-7xl mx-auto px-6">
        <div className="grid grid-cols-1 lg:grid-cols-12 gap-12 items-center">
          
          {/* Left image wrapped in custom shapes */}
          <div className="lg:col-span-5 relative">
            <div className="absolute -top-4 -left-4 w-12 h-12 rounded-full border border-amber-400 animate-pulse duration-3000 pointer-events-none" />
            <div className="relative rounded-2xl overflow-hidden shadow-2xl border border-slate-200 group">
              <img
                src="https://images.unsplash.com/photo-1531123897727-8f129e1688ce?w=600&q=80"
                alt="Équipe Luciole-services au travail"
                className="w-full h-auto object-cover transform scale-100 group-hover:scale-105 transition-transform duration-700 ease-out"
              />
            </div>
            <div className="absolute -bottom-4 -right-4 w-16 h-16 rounded-2xl bg-amber-400/10 -z-10" />
          </div>

          {/* Right Text details */}
          <div className="lg:col-span-7 flex flex-col text-left">
            <span className="text-amber-600 font-bold text-xs uppercase tracking-widest block mb-3">
              À propos de Luciole-services
            </span>
            
            <h2 className="font-display font-bold text-3xl sm:text-4xl text-slate-900 leading-tight mb-6">
              Une équipe passionnée au service de votre réussite
            </h2>
            
            <p className="text-slate-500 text-sm sm:text-base leading-relaxed mb-4 italic">
              Luciole-services est une agence créative spécialisée dans l'ingénierie digitale et la communication audiovisuelle basée à Douala. Nous accompagnons les créateurs, entreprises, professionnels et institutions dans la mise en œuvre de solutions connectées sur-mesure.
            </p>
            
            <p className="text-slate-500 text-sm sm:text-base leading-relaxed mb-8 italic">
              Notre ambition est simple : propulser votre rayonnement professionnel en vous offrant un écosystème d'outils optimisés, fluides, parfaitement sécurisés et dotés d'une élégance sans compromis. Tarifs transparents, réactivité de pointe et qualité sur-mesure garantis à chaque étape.
            </p>

            {/* Micro Stats Counter panel */}
            <div className="grid grid-cols-3 gap-6 bg-slate-50 rounded-2xl p-6 border border-slate-200 shadow-sm">
              <div className="text-center">
                <span className="text-2xl sm:text-3xl font-display font-black text-slate-900 block mb-1">
                  {counts.projects}+
                </span>
                <span className="text-xs sm:text-sm font-semibold text-slate-500 block">
                  Projets Livrés
                </span>
              </div>
              
              <div className="text-center border-x border-slate-200">
                <span className="text-2xl sm:text-3xl font-display font-black text-slate-900 block mb-1">
                  {counts.clients}+
                </span>
                <span className="text-xs sm:text-sm font-semibold text-slate-500 block">
                  Clients Heureux
                </span>
              </div>

              <div className="text-center">
                <span className="text-2xl sm:text-3xl font-display font-black text-slate-900 block mb-1">
                  {counts.skills}+
                </span>
                <span className="text-xs sm:text-sm font-semibold text-slate-500 block">
                  Pôles d'Expertise
                </span>
              </div>
            </div>
          </div>
          
        </div>
      </div>
    </section>
  );
}
