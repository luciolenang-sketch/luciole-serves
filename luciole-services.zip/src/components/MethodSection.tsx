import React from "react";
import { Coffee, MessageSquare, Compass, CheckCircle2 } from "lucide-react";

const steps = [
  {
    num: "1",
    title: "Échange & analyse",
    description: "Nous écoutons vos idées avec attention pour cartographier vos besoins d'affaires uniques.",
    icon: <MessageSquare className="w-5 h-5 text-amber-600" />
  },
  {
    num: "2",
    title: "Conception & design",
    description: "Nous concevons l'architecture d'information, l'ergonomie UX et le design graphique élégant.",
    icon: <Compass className="w-5 h-5 text-amber-600" />
  },
  {
    num: "3",
    title: "Réalisation & code",
    description: "Notre équipe développe le code avec rigueur puis peaufine les finitions audiovisuelles de pointe.",
    icon: <Coffee className="w-5 h-5 text-amber-600" />
  },
  {
    num: "4",
    title: "Livraison & suivi",
    description: "Nous déployons vos outils clé en main, formons vos équipes et assurons le support continu.",
    icon: <CheckCircle2 className="w-5 h-5 text-amber-600" />
  }
];

export default function MethodSection() {
  return (
    <section className="py-24 bg-slate-50 border-t border-slate-150">
      <div className="max-w-7xl mx-auto px-6">
        {/* Section Heading */}
        <div className="text-center max-w-2xl mx-auto mb-16">
          <span className="text-amber-600 font-bold text-xs uppercase tracking-widest block mb-3">
            Notre méthode de travail
          </span>
          <h2 className="font-display font-bold text-3xl sm:text-4xl text-slate-900 leading-tight mb-4">
            Comment se déroule un projet mémorable
          </h2>
          <p className="text-slate-500 text-sm sm:text-base leading-relaxed italic">
            Un processus clair, rigoureux et collaboratif de A à Z pour propulser vos ambitions créatives ou numériques.
          </p>
        </div>

        {/* Steps Grid */}
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-8">
          {steps.map((step) => (
            <div
              key={step.num}
              className="bg-white rounded-2xl p-8 border border-slate-200 shadow-sm hover:shadow-xl hover:shadow-slate-200/50 hover:border-amber-400 transition-all duration-300 relative group text-center flex flex-col items-center"
            >
              {/* Stepper badge with step number and icons */}
              <div className="w-14 h-14 rounded-full bg-slate-900 text-amber-400 font-display font-extrabold text-xl flex items-center justify-center mb-6 relative transition-all duration-300 group-hover:bg-amber-400 group-hover:text-slate-900 group-hover:rotate-[360deg]">
                {step.num}
              </div>

              <h4 className="font-display font-bold text-lg text-slate-900 mb-3 group-hover:text-amber-600 transition-colors duration-200">
                {step.title}
              </h4>
              
              <p className="text-slate-500 text-sm leading-relaxed">
                {step.description}
              </p>
            </div>
          ))}
        </div>
      </div>
    </section>
  );
}
