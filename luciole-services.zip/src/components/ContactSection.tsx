import React, { useState } from "react";
import { Phone, Mail, MapPin, Send, CheckCircle2, MessageSquare, ArrowRight, Facebook, Instagram } from "lucide-react";

export default function ContactSection() {
  const [formData, setFormData] = useState({
    name: "",
    phone: "",
    service: "",
    message: ""
  });
  
  const [isSubmitting, setIsSubmitting] = useState(false);
  const [showSuccessToast, setShowSuccessToast] = useState(false);

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    setIsSubmitting(true);

    // Simulate sending
    setTimeout(() => {
      setIsSubmitting(false);
      setShowSuccessToast(true);
      setFormData({ name: "", phone: "", service: "", message: "" });
      
      // Auto hide success toast after 5s
      setTimeout(() => {
        setShowSuccessToast(false);
      }, 5000);
    }, 1200);
  };

  return (
    <>
      {/* CTA BAND */}
      <section className="py-16 bg-gradient-to-r from-amber-400 to-amber-300 text-slate-900 transition-colors duration-300">
        <div className="max-w-4xl mx-auto px-6 text-center">
          <h2 className="font-display font-black text-2xl sm:text-3xl lg:text-4xl leading-tight mb-4 text-slate-900">
            Prêt à donner vie à votre projet d'exception ?
          </h2>
          <p className="text-slate-900/80 text-sm sm:text-base font-semibold max-w-xl mx-auto mb-8">
            Contactez Luciole-services dès aujourd'hui et obtenez un devis gratuit complet en moins de 24 heures.
          </p>
          <a
            href="#contact"
            className="bg-slate-900 hover:bg-slate-800 text-white font-bold px-8 py-3.5 rounded-lg transition-all duration-300 inline-flex items-center gap-2 shadow-lg shadow-slate-950/20"
          >
            Contactez-nous maintenant <ArrowRight className="w-4 h-4" />
          </a>
        </div>
      </section>

      {/* CONTACT MAIN SECTION */}
      <section id="contact" className="py-24 bg-white relative">
        <div className="max-w-7xl mx-auto px-6">
          <div className="grid grid-cols-1 lg:grid-cols-2 gap-12">
            
            {/* Contact Information */}
            <div className="flex flex-col text-left justify-center">
              <span className="text-amber-600 font-bold text-xs uppercase tracking-widest block mb-3">
                Contactez-nous
              </span>
              <h2 className="font-display font-bold text-3xl sm:text-4xl text-slate-900 leading-tight mb-6">
                Discutons de votre prochain projet d'envergure
              </h2>
              <p className="text-slate-500 text-sm sm:text-base leading-relaxed mb-8 italic">
                Des questions sur l'un de nos pôles d'activité ou besoin d'un chiffrage sur-mesure ? Notre équipe est mobilisée à Douala pour répondre à l'intégralité de vos besoins en un temps record.
              </p>

              {/* Items Card list */}
              <div className="space-y-6">
                {[
                  {
                    title: "Téléphone / WhatsApp",
                    value: "+237 699 95 80 89",
                    icon: <Phone className="w-5 h-5 text-amber-600" />,
                    link: "https://wa.me/237699958089"
                  },
                  {
                    title: "Adresse Email",
                    value: "divis@luciole-serves.com",
                    icon: <Mail className="w-5 h-5 text-amber-600" />,
                    link: "mailto:divis@luciole-serves.com"
                  },
                  {
                    title: "Localisation",
                    value: "Douala, Cameroun",
                    icon: <MapPin className="w-5 h-5 text-amber-600" />,
                    link: "#"
                  }
                ].map((item, idx) => (
                  <a
                    key={idx}
                    href={item.link}
                    target={item.link.startsWith("http") ? "_blank" : undefined}
                    rel={item.link.startsWith("http") ? "noopener noreferrer" : undefined}
                    className="flex items-start gap-4 p-4 rounded-xl hover:bg-slate-50 transition-colors duration-300 group block border border-transparent hover:border-slate-200"
                  >
                    <div className="w-11 h-11 rounded-full bg-slate-100 group-hover:bg-amber-400 group-hover:text-slate-900 flex items-center justify-center transition-all duration-300 text-amber-600 shrink-0">
                      {item.icon}
                    </div>
                    <div>
                      <h4 className="font-display font-bold text-slate-900 text-sm mb-1">
                        {item.title}
                      </h4>
                      <p className="text-slate-500 text-sm font-semibold group-hover:text-amber-600 transition-colors duration-200">
                        {item.value}
                      </p>
                    </div>
                  </a>
                ))}

                {/* Relocated social networks with beautiful visual container */}
                <div className="p-5 rounded-xl border border-slate-200 bg-amber-50/10 shadow-sm relative overflow-hidden transition-all duration-300 hover:border-amber-400">
                  <div className="absolute top-0 right-0 w-24 h-24 bg-amber-400/5 rounded-full -mr-8 -mt-8 pointer-events-none" />
                  <p className="text-xs text-slate-700 font-extrabold mb-3 uppercase tracking-wider flex items-center gap-2">
                    <span className="w-1.5 h-1.5 rounded-full bg-amber-500"></span>
                    Vous pouvez aussi nous joindre sur les réseaux :
                  </p>
                  <div className="flex flex-wrap gap-3">
                    <a 
                      href="https://www.facebook.com/share/1AWzpnveXJ/" 
                      target="_blank" 
                      rel="noopener noreferrer"
                      className="inline-flex items-center gap-2 px-4 py-2.5 text-xs font-bold text-white bg-[#1877F2] hover:bg-[#1877F2]/90 rounded-lg transition-all duration-300 shadow-md transform hover:-translate-y-1 hover:shadow-[#1877F2]/20"
                    >
                      <Facebook className="w-4 h-4 fill-current" />
                      Facebook
                    </a>
                    <a 
                      href="https://www.instagram.com/lucioleservices?igsh=dzZwdGM4MmJwZHE4" 
                      target="_blank" 
                      rel="noopener noreferrer"
                      className="inline-flex items-center gap-2 px-4 py-2.5 text-xs font-bold text-white bg-gradient-to-tr from-[#F58529] via-[#DD2A7B] to-[#8134AF] hover:opacity-95 rounded-lg transition-all duration-300 shadow-md transform hover:-translate-y-1 hover:shadow-[#DD2A7B]/20"
                    >
                      <Instagram className="w-4 h-4" />
                      Instagram
                    </a>
                  </div>
                </div>
              </div>
            </div>

            {/* Contact Form representation */}
            <div className="bg-slate-50 rounded-2xl p-8 border border-slate-200 shadow-sm">
              <form onSubmit={handleSubmit} className="space-y-4">
                <div>
                  <label htmlFor="name" className="block text-xs font-bold text-slate-500 uppercase tracking-wider mb-2">
                    Votre nom complet
                  </label>
                  <input
                    type="text"
                    id="name"
                    required
                    value={formData.name}
                    onChange={(e) => setFormData({ ...formData, name: e.target.value })}
                    className="w-full bg-white rounded-lg border border-slate-300 py-3.5 px-4 text-sm focus:outline-none focus:border-amber-400 focus:ring-4 focus:ring-amber-400/20 transition-all duration-300 placeholder-slate-400"
                    placeholder="Nom complet"
                  />
                </div>

                <div>
                  <label htmlFor="phone" className="block text-xs font-bold text-slate-500 uppercase tracking-wider mb-2">
                    Votre numéro de téléphone
                  </label>
                  <input
                    type="tel"
                    id="phone"
                    required
                    value={formData.phone}
                    onChange={(e) => setFormData({ ...formData, phone: e.target.value })}
                    className="w-full bg-white rounded-lg border border-slate-300 py-3.5 px-4 text-sm focus:outline-none focus:border-amber-400 focus:ring-4 focus:ring-amber-400/20 transition-all duration-300 placeholder-slate-400"
                    placeholder="Numéro de contact"
                  />
                </div>

                <div>
                  <label htmlFor="service" className="block text-xs font-bold text-slate-500 uppercase tracking-wider mb-2">
                    Choisissez un service
                  </label>
                  <select
                    id="service"
                    required
                    value={formData.service}
                    onChange={(e) => setFormData({ ...formData, service: e.target.value })}
                    className="w-full bg-white rounded-lg border border-slate-300 py-3.5 px-4 text-sm focus:outline-none focus:border-amber-400 focus:ring-4 focus:ring-amber-400/20 transition-all duration-300 cursor-pointer text-slate-600 font-medium"
                  >
                    <option value="">Sélectionner un type de projet</option>
                    <option>Création de site web</option>
                    <option>Application iOS / Android</option>
                    <option>Gestion de base de données</option>
                    <option>Design graphique</option>
                    <option>Spot publicitaire / audiovisuel</option>
                    <option>Voix off professionnelle</option>
                    <option>Jingle mémorable</option>
                    <option>Autre prestation de service</option>
                  </select>
                </div>

                <div>
                  <label htmlFor="message" className="block text-xs font-bold text-slate-500 uppercase tracking-wider mb-2">
                    Décrivez votre projet
                  </label>
                  <textarea
                    id="message"
                    required
                    rows={4}
                    value={formData.message}
                    onChange={(e) => setFormData({ ...formData, message: e.target.value })}
                    className="w-full bg-white rounded-lg border border-slate-300 py-3.5 px-4 text-sm focus:outline-none focus:border-amber-400 focus:ring-4 focus:ring-amber-400/20 transition-all duration-300 resize-none placeholder-slate-400"
                    placeholder="Quelles sont vos attentes de notre équipe ?"
                  />
                </div>

                <button
                  type="submit"
                  disabled={isSubmitting}
                  className="w-full bg-slate-900 hover:bg-amber-400 text-white hover:text-slate-950 font-bold py-4 rounded-lg transition-all duration-300 flex items-center justify-center gap-2 cursor-pointer shadow-md hover:shadow-lg hover:shadow-amber-400/20"
                >
                  {isSubmitting ? (
                    <div className="w-5 h-5 border-2 border-white border-t-transparent rounded-full animate-spin" />
                  ) : (
                    <>
                      Envoyer la demande <Send className="w-4 h-4" />
                    </>
                  )}
                </button>
              </form>
            </div>

          </div>
        </div>
      </section>

      {/* SUCCESS TOAST MODAL */}
      {showSuccessToast && (
        <div className="fixed bottom-24 right-6 z-50 bg-slate-950 text-white p-5 rounded-2xl shadow-2xl flex items-start gap-3 border border-slate-800 animate-slideUp max-w-sm">
          <div className="bg-amber-400 p-1.5 rounded-full text-slate-950 shrink-0 mt-0.5">
            <CheckCircle2 className="w-4 h-4" />
          </div>
          <div>
            <h5 className="font-bold text-sm text-amber-400 mb-1">Demande reçue !</h5>
            <p className="text-xs text-slate-300 leading-relaxed">
              Nous vous remercions pour votre confiance. Un expert Luciole-services reviendra vers vous sous 24h ouvrées.
            </p>
          </div>
        </div>
      )}

      {/* WHATSAPP FLOATING BUTTON */}
      <a
        href="https://wa.me/237699958089"
        target="_blank"
        rel="noopener noreferrer"
        aria-label="Contacter Luciole Services via WhatsApp"
        className="fixed bottom-6 right-6 z-[999] w-15 h-15 bg-[#25D366] rounded-full flex items-center justify-center text-white shadow-2xl hover:scale-110 active:scale-95 transition-transform duration-300"
        style={{ boxShadow: "0 8px 24px rgba(37,211,102,0.4)" }}
      >
        <MessageSquare className="w-7 h-7 fill-white text-[#25D366]" />
      </a>
    </>
  );
}
