/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 */

import React, { useState } from "react";
import { VOICE_PROFILES, MOCK_SOUND_EFFECTS } from "../data";
import { VoiceProfile, SoundEffect } from "../types";
import { speakText, playSynthTone } from "../utils";
import { Mic, Play, Square, Volume2, Music, Waves, CheckCircle2 } from "lucide-react";

export const AudioStudio: React.FC = () => {
  const [selectedVoice, setSelectedVoice] = useState<VoiceProfile>(VOICE_PROFILES[0]);
  const [customText, setCustomText] = useState<string>(VOICE_PROFILES[0].sampleText);
  const [isSpeaking, setIsSpeaking] = useState<boolean>(false);
  const [mixerVolume, setMixerVolume] = useState<number>(70);

  const handleVoiceChange = (voice: VoiceProfile) => {
    setSelectedVoice(voice);
    setCustomText(voice.sampleText);
  };

  const handleSpeak = () => {
    setIsSpeaking(true);
    speakText(customText, selectedVoice.gender === "femme");
    // Simulate end of speaking after safe duration (or hook utterance event, but local simulation is robust)
    const durationCount = Math.max(1500, customText.length * 68);
    setTimeout(() => {
      setIsSpeaking(false);
    }, durationCount);
  };

  const handleStopSpeaking = () => {
    try {
      if ("speechSynthesis" in window) {
        window.speechSynthesis.cancel();
      }
    } catch (_) {}
    setIsSpeaking(false);
  };

  const triggerSfxSynth = (sfx: SoundEffect) => {
    playSynthTone(sfx.frequency, sfx.type, sfx.duration);
  };

  return (
    <section id="vocal-studio" className="py-24 bg-transparent text-white relative overflow-hidden">
      {/* Decorative backdrop graphics */}
      <div className="absolute top-0 right-0 w-96 h-96 bg-gold/5 rounded-full blur-3xl pointer-events-none" />
      <div className="absolute bottom-0 left-0 w-96 h-96 bg-gold-light/5 rounded-full blur-3xl pointer-events-none" />

      <div className="max-w-7xl mx-auto px-6 relative z-10">
        {/* Header section */}
        <div className="text-center max-w-3xl mx-auto mb-16">
          <span className="text-gold font-bold uppercase tracking-[0.2em] text-xs block mb-3">
            Studio Vocal Interactif
          </span>
          <h2 className="font-display font-black text-3xl sm:text-4xl leading-tight mb-4 text-white">
            Choisissez la voix de votre marque.
          </h2>
          <p className="text-slate-400 text-lg leading-relaxed">
            Écrivez un texte et synthétisez instantanément la voix off de votre choix ! 
            Utilisez notre table de mixage interactive pour écouter des bruitages et jingles.
          </p>
        </div>

        <div className="grid grid-cols-1 lg:grid-cols-12 gap-12 items-start">
          {/* Left panel: Voice profiles list selector */}
          <div className="lg:col-span-4 flex flex-col gap-4">
            <h3 className="font-display font-bold text-lg text-white/95 mb-2 flex items-center gap-2">
              <Mic size={18} className="text-gold" />
              Nos Talents Vocal
            </h3>

            {VOICE_PROFILES.map((voice) => (
              <button
                key={voice.id}
                onClick={() => handleVoiceChange(voice)}
                className={`w-full p-5 rounded-2xl border text-left cursor-pointer transition-all duration-300 flex items-center justify-between ${
                  selectedVoice.id === voice.id
                    ? "bg-gold/15 text-white border-gold shadow-xl shadow-gold/10"
                    : "bg-white/5 border-white/10 text-white/90 hover:bg-white/10 hover:border-white/20"
                }`}
              >
                <div>
                  <div className="flex items-center gap-2 mb-1.5">
                    <span className="text-xs font-bold uppercase tracking-wider bg-gold/25 text-gold px-2.5 py-0.5 rounded-full">
                      {voice.gender === "homme" ? "Voix Homme" : "Voix Femme"}
                    </span>
                    <span className="text-[10px] text-slate-400 font-semibold">{voice.tone}</span>
                  </div>
                  <h4 className="font-display font-black text-base truncate">{voice.name}</h4>
                  <p className={`text-xs mt-1 leading-normal line-clamp-2 ${selectedVoice.id === voice.id ? "text-slate-100" : "text-slate-400"}`}>
                    {voice.description}
                  </p>
                </div>
              </button>
            ))}
          </div>

          {/* Right panel: Synthesizer playground console */}
          <div className="lg:col-span-8 flex flex-col gap-6">
            <div className="bg-[#1e293b]/30 backdrop-blur-md rounded-3xl p-6 sm:p-8 border border-white/5 shadow-2xl relative">
              <div className="flex items-center justify-between gap-4 mb-6 pb-4 border-b border-white/5">
                <div className="flex items-center gap-3">
                  <div className="w-10 h-10 rounded-full bg-gold/15 text-gold flex items-center justify-center text-lg animate-pulse">
                    🎤
                  </div>
                  <div>
                    <h4 className="text-sm font-bold text-white/95">Studio Cabine active</h4>
                    <p className="text-[10px] text-slate-400">Prêt pour l'enregistrement</p>
                  </div>
                </div>

                {/* Simulated waveforms indicator */}
                {isSpeaking && (
                  <div className="flex items-end gap-1 h-6" aria-hidden="true">
                    {[16, 24, 12, 28, 16, 24, 14, 20].map((h, i) => (
                      <div
                        key={i}
                        className="w-1 bg-gold rounded-full animate-pulse-slow"
                        style={{
                          height: `${h}px`,
                          animationDuration: `${0.4 + i * 0.08}s`,
                        }}
                      />
                    ))}
                  </div>
                )}
              </div>

              {/* Text Area field */}
              <div className="relative mb-6">
                <label htmlFor="voice-textarea" className="absolute top-[2px] left-4 text-[10px] font-bold text-gold uppercase tracking-wider">
                  Script de la voix off
                </label>
                <textarea
                  id="voice-textarea"
                  value={customText}
                  onChange={(e) => setCustomText(e.target.value)}
                  maxLength={180}
                  className="w-full bg-[#020617]/50 border border-white/10 rounded-2xl px-5 pb-5 pt-8 text-sm focus:outline-none focus:border-gold placeholder:text-white/20 text-white/90 resize-none h-28"
                  placeholder="Écrivez le message publicitaire ou la narration pour tester la voix..."
                />
                <span className="absolute bottom-2.5 right-4 text-[10px] text-slate-500 font-semibold">
                  {customText.length}/180 caractères
                </span>
              </div>

              {/* Console Trigger buttons */}
              <div className="flex flex-wrap gap-4 mb-6">
                {!isSpeaking ? (
                  <button
                    onClick={handleSpeak}
                    disabled={!customText.trim()}
                    className="flex-1 py-4 px-6 rounded-xl font-bold bg-gold text-white hover:bg-gold-light transition duration-150 shadow-lg shadow-gold/20 flex items-center justify-center gap-2 cursor-pointer disabled:opacity-40"
                  >
                    <Play size={16} /> Écouter la démo
                  </button>
                ) : (
                  <button
                    onClick={handleStopSpeaking}
                    className="flex-1 py-4 px-6 rounded-xl font-bold bg-red-600 hover:bg-red-500 text-white transition duration-150 flex items-center justify-center gap-2 cursor-pointer animate-pulse"
                  >
                    <Square size={16} /> Arrêter la lecture
                  </button>
                )}
              </div>

              {/* Sound Board Mixing tray fallback */}
              <div className="border-t border-white/5 pt-6">
                <h4 className="font-display font-medium text-xs text-white/80 uppercase tracking-widest mb-4 flex items-center gap-2">
                  <Music size={14} className="text-gold" />
                  Table de Mixage & Effets Sonores (Synth)
                </h4>

                <div className="grid grid-cols-2 sm:grid-cols-4 gap-3 mb-6">
                  {MOCK_SOUND_EFFECTS.map((sfx) => (
                    <button
                      key={sfx.id}
                      onClick={() => triggerSfxSynth(sfx)}
                      className="px-4 py-3 bg-white/5 hover:bg-gold/15 text-white hover:text-gold border border-white/10 hover:border-gold/30 rounded-xl text-center text-xs font-bold flex items-center justify-center gap-1.5 transition-all duration-250 cursor-pointer"
                    >
                      <span>{sfx.emoji}</span>
                      {sfx.name}
                    </button>
                  ))}
                </div>

                {/* Slider volume parameters */}
                <div className="flex items-center gap-4 bg-navy-dark/[0.5] p-4 rounded-xl border border-white/5">
                  <Volume2 size={16} className="text-gray-400" />
                  <div className="flex-1 select-none">
                    <span className="text-[10px] text-gray-400 font-bold uppercase tracking-wider block">
                      Volume de monitoring studio ({mixerVolume}%)
                    </span>
                    <input
                      type="range"
                      min="0"
                      max="100"
                      value={mixerVolume}
                      onChange={(e) => setMixerVolume(+e.target.value)}
                      className="w-full accent-gold h-1 rounded-lg cursor-pointer bg-white/15"
                      aria-label="Volume Level"
                    />
                  </div>
                  <div className="flex items-center gap-1.5 shrink-0 text-[#8D6e63]">
                    <span className="w-2 h-2 rounded-full bg-[#8D6e63] shrink-0" />
                    <span className="text-[10px] font-bold text-gray-400 uppercase tracking-wider">Dolby Atmos</span>
                  </div>
                </div>
              </div>
            </div>
            
            {/* Disclaimer for full-fidelity and production */}
            <div className="flex items-start gap-3 bg-gold/10 p-5 rounded-2xl border border-gold/15">
              <CheckCircle2 size={18} className="text-gold shrink-0 mt-0.5" />
              <p className="text-xs text-gray-300 leading-normal">
                <strong>Pack Jingle complet :</strong> Comprend l'écriture, le recrutement du comédien parmi notre réseau national, le nettoyage stéréophonique, et la masterisation audio finale. Un chef d'œuvre prêt à la diffusion radio-télévision ou internet.
              </p>
            </div>
          </div>
        </div>
      </div>
    </section>
  );
};
