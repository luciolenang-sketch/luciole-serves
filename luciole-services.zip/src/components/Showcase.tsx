import React, { useState } from "react";
import { ExternalLink, Layers, Layout, Layers2, ArrowRight } from "lucide-react";

interface Project {
  id: string;
  title: string;
  category: "sites" | "apps";
  image: string;
  description: string;
}

const projects: Project[] = [
  {
    id: "site-1",
    title: "Boutique en ligne",
    category: "sites",
    image: "https://images.unsplash.com/photo-1467232004584-a241de8bcf5d?w=500&q=80",
    description: "Site e-commerce moderne, sécurisé et 100% responsive."
  },
  {
    id: "site-2",
    title: "Site vitrine corporate",
    category: "sites",
    image: "https://images.unsplash.com/photo-1547658719-da2b51169166?w=500&q=80",
    description: "Présentation institutionnelle et stratégie d'acquisition de prospects."
  },
  {
    id: "site-3",
    title: "Tableau de bord web",
    category: "sites",
    image: "https://images.unsplash.com/photo-1460925895917-afdab827c52f?w=500&q=80",
    description: "Interface métier d'analyse connectée à des bases de données SQL."
  },
  {
    id: "app-1",
    title: "Application de gestion",
    category: "apps",
    image: "https://images.unsplash.com/photo-1551650975-87deedd944c3?w=500&q=80",
    description: "Suivi et tableau de bord opérationnel d'activité d'usine en temps réel."
  },
  {
    id: "app-2",
    title: "Application de réservation",
    category: "apps",
    image: "https://images.unsplash.com/photo-1512941937669-90a1b58e7e9c?w=500&q=80",
    description: "Prises de rendez-vous instantanées, agendas partagés et rappels SMS/Push."
  },
  {
    id: "app-3",
    title: "App e-commerce mobile",
    category: "apps",
    image: "https://images.unsplash.com/photo-1601972602288-3be527b4f18a?w=500&q=80",
    description: "Parcours d'achat moderne optimisé sur iOS, iPadOS et Android."
  }
];

export default function Showcase() {
  const [activeTab, setActiveTab] = useState<"sites" | "apps">("sites");

  const filteredProjects = projects.filter((p) => p.category === activeTab);

  return (
    <section id="realisations" className="py-24 bg-white transition-all duration-300">
      <div className="max-w-7xl mx-auto px-6">
        {/* Section Heading */}
        <div className="text-center max-w-2xl mx-auto mb-16">
          <span className="text-amber-600 font-bold text-xs uppercase tracking-widest block mb-3">
            Portfolio
          </span>
          <h2 className="font-display font-bold text-3xl sm:text-4xl text-slate-900 leading-tight mb-4">
            Un aperçu mémorable de notre travail
          </h2>
          <p className="text-slate-500 text-sm sm:text-base leading-relaxed italic">
            Découvrez une sélection choisie de sites internet sophistiqués et d'applications mobiles que nous avons conçus de bout en bout pour nos clients.
          </p>
        </div>

        {/* Tab Controls */}
        <div className="flex justify-center gap-4 mb-12">
          <button
            onClick={() => setActiveTab("sites")}
            className={`px-6 py-2.5 rounded-lg font-bold text-sm tracking-wide transition-all duration-300 flex items-center gap-2 cursor-pointer ${
              activeTab === "sites"
                ? "bg-slate-900 text-white shadow-lg shadow-slate-900/20"
                : "bg-slate-50 text-slate-600 hover:bg-slate-100"
            }`}
          >
            <Layout className="w-4 h-4" />
            Sites web
          </button>
          <button
            onClick={() => setActiveTab("apps")}
            className={`px-6 py-2.5 rounded-lg font-bold text-sm tracking-wide transition-all duration-300 flex items-center gap-2 cursor-pointer ${
              activeTab === "apps"
                ? "bg-slate-900 text-white shadow-lg shadow-slate-900/20"
                : "bg-slate-50 text-slate-600 hover:bg-slate-100"
            }`}
          >
            <Layers2 className="w-4 h-4" />
            Applications mobiles
          </button>
        </div>

        {/* Tab Content Cards container */}
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-8 justify-items-center">
          {filteredProjects.map((project) => (
            <div
              key={project.id}
              className="w-full bg-slate-50 rounded-2xl overflow-hidden shadow-sm hover:shadow-xl hover:shadow-slate-200/50 hover:-translate-y-2 transition-all duration-300 group border border-slate-200"
            >
              {/* Image holder */}
              <div className="relative overflow-hidden h-56 w-full">
                <img
                  src={project.image}
                  alt={project.title}
                  className="w-full h-full object-cover transition-transform duration-700 ease-out group-hover:scale-108"
                />
                
                {/* Overlay hover */}
                <div className="absolute inset-0 bg-gradient-to-t from-slate-950/80 via-transparent to-transparent opacity-0 group-hover:opacity-100 transition-opacity duration-300 flex items-end p-6">
                  <span className="text-slate-900 font-bold text-xs inline-flex items-center gap-1.5 bg-amber-400 px-3 py-1 rounded-md w-max">
                    <ExternalLink className="w-3.5 h-3.5" />
                    Voir le projet
                  </span>
                </div>
              </div>

              {/* Info Area */}
              <div className="p-6">
                <h4 className="font-display font-bold text-slate-900 text-lg mb-2 group-hover:text-amber-600 transition-colors duration-250">
                  {project.title}
                </h4>
                <p className="text-slate-500 text-sm leading-relaxed">
                  {project.description}
                </p>
              </div>
            </div>
          ))}
        </div>

        {/* Call to action inside Showcase */}
        <div className="mt-16 text-center animate-fadeIn">
          <p className="text-slate-600 text-sm mb-4 font-medium italic">
            Prêt à faire passer votre présentation ou outil digital au niveau supérieur ?
          </p>
          <a
            href="#contact"
            className="inline-flex items-center gap-2 bg-slate-900 hover:bg-amber-400 text-white hover:text-slate-950 px-8 py-3.5 rounded-lg font-bold transition-all duration-300 shadow-md hover:shadow-lg hover:shadow-amber-400/20"
          >
            Demander un devis pour mon projet <ArrowRight className="w-4 h-4" />
          </a>
        </div>
      </div>
    </section>
  );
}
