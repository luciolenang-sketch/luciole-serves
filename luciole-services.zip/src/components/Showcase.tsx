/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 */

import React, { useState } from "react";
import { SHOWCASE_ITEMS } from "../data";
import { ShowcaseItem } from "../types";
import { ShowcaseIllustration } from "./Illustrations";
import { ExternalLink, Calendar, User, LayoutGrid } from "lucide-react";

export const Showcase: React.FC = () => {
  const [activeCategory, setActiveCategory] = useState<"tous" | "sites" | "apps" | "design">("tous");
  const [selectedProject, setSelectedProject] = useState<ShowcaseItem | null>(null);

  const categories = [
    { label: "Tout voir", id: "tous" },
    { label: "Sites Internet", id: "sites" },
    { label: "Applications Mobiles", id: "apps" },
    { label: "Identités & Design", id: "design" },
  ] as const;

  const filteredProjects = SHOWCASE_ITEMS.filter(
    (item) => activeCategory === "tous" || item.category === activeCategory
  );

  return (
    <section id="realisations" className="py-24 bg-transparent text-slate-100">
      <div className="max-w-7xl mx-auto px-6">
        {/* Section header */}
        <div className="text-center max-w-3xl mx-auto mb-16">
          <span className="text-gold font-bold uppercase tracking-[0.2em] text-xs block mb-3">
            Nos Réalisations Récentes
          </span>
          <h2 className="font-display font-black text-3xl sm:text-4xl text-white leading-tight mb-4">
            Un aperçu concret de notre savoir-faire.
          </h2>
          <p className="text-slate-400 text-lg leading-relaxed">
            Pas de fausses promesses ou d'images génériques. Découvrez nos projets réels développés
            pour des structures audacieuses au Cameroun et à l'international.
          </p>
        </div>

        {/* Tab category selectors */}
        <div className="flex flex-wrap justify-center gap-3 mb-12">
          {categories.map((cat) => (
            <button
              key={cat.id}
              onClick={() => setActiveCategory(cat.id)}
              className={`px-6 py-3 rounded-full text-sm font-bold border transition duration-200 cursor-pointer ${
                activeCategory === cat.id
                  ? "bg-gold text-white border-gold shadow-lg shadow-gold/25"
                  : "bg-white/5 text-slate-300 border-white/10 hover:border-gold/30 hover:bg-white/10"
              }`}
            >
              {cat.label}
            </button>
          ))}
        </div>

        {/* Dynamic Cards Grid */}
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-8">
          {filteredProjects.map((item) => (
            <div
              key={item.id}
              onClick={() => setSelectedProject(item)}
              className="group bg-[#1e293b]/30 backdrop-blur-md rounded-2xl overflow-hidden shadow-xl hover:shadow-2xl border border-white/5 hover:border-gold/30 cursor-pointer transition-all duration-300 flex flex-col h-full relative"
            >
              {/* Card visual using dynamic illustration layout */}
              <div className="relative aspect-video w-full overflow-hidden bg-navy-dark">
                <ShowcaseIllustration type={item.svgKey} />
                <div className="absolute inset-0 bg-navy-dark/60 opacity-0 group-hover:opacity-100 transition-all duration-300 flex items-center justify-center">
                  <span className="px-5 py-2.5 rounded-full text-xs font-bold uppercase tracking-wider bg-gold text-white shadow-md flex items-center gap-1.5 transform translate-y-3 group-hover:translate-y-0 transition duration-300">
                    <ExternalLink size={14} /> Voir le projet
                  </span>
                </div>
              </div>

              {/* Card text metadata */}
              <div className="p-6 flex flex-col justify-between flex-1">
                <div>
                  <span className="inline-block text-[10px] font-bold text-gold uppercase tracking-widest mb-2">
                    {item.badge}
                  </span>
                  <h3 className="font-display font-black text-lg text-white group-hover:text-gold transition">
                    {item.title}
                  </h3>
                  <p className="text-slate-400 text-xs mt-1 truncate">{item.subtitle}</p>
                </div>

                <div className="flex flex-wrap gap-1.5 mt-4">
                  {item.techs.slice(0, 3).map((t, i) => (
                    <span
                      key={i}
                      className="text-[10px] bg-white/5 border border-white/10 text-slate-300 font-semibold px-2 py-0.5 rounded"
                    >
                      {t}
                    </span>
                  ))}
                  {item.techs.length > 3 && (
                    <span className="text-[10px] bg-white/5 border border-white/10 text-slate-400 font-semibold px-1 py-0.5 rounded">
                      +{item.techs.length - 3}
                    </span>
                  )}
                </div>
              </div>
            </div>
          ))}
        </div>

        {/* Modal details container */}
        {selectedProject && (
          <div className="fixed inset-0 z-55 bg-black/70 backdrop-blur-sm flex items-center justify-center p-6 animate-fadeUp">
            <div className="bg-[#0f172a] rounded-3xl max-w-2xl w-full max-h-[90vh] overflow-y-auto shadow-2xl relative border border-white/10 p-8 text-white">
              <button
                onClick={() => setSelectedProject(null)}
                className="absolute top-5 right-5 text-slate-400 hover:text-white hover:bg-white/10 p-2 rounded-full transition"
                aria-label="Fermer"
              >
                ✕
              </button>

              <div className="flex items-center gap-2 text-gold font-bold text-xs uppercase tracking-widest mb-3">
                <LayoutGrid size={13} />
                {selectedProject.badge}
              </div>

              <h3 className="font-display font-black text-2xl sm:text-3xl text-white leading-tight mb-2">
                {selectedProject.title}
              </h3>
              <p className="text-slate-400 text-sm mb-6 pb-4 border-b border-white/5">
                {selectedProject.subtitle}
              </p>

              {/* SVG Graphic inside modal details banner */}
              <div className="rounded-xl overflow-hidden aspect-video bg-navy-dark mb-6 border border-white/5 shadow-inner">
                <ShowcaseIllustration type={selectedProject.svgKey} />
              </div>

              {/* Specific metadata list */}
              <div className="grid grid-cols-1 sm:grid-cols-3 gap-4 mb-6 py-4 bg-[#1e293b]/50 border border-white/5 rounded-2xl px-6">
                <div className="flex items-center gap-3">
                  <div className="p-2 rounded-full bg-white/5 text-gold">
                    <User size={16} />
                  </div>
                  <div>
                    <span className="text-[10px] text-slate-400 font-medium uppercase block">Client</span>
                    <span className="text-xs font-bold text-white truncate leading-none block">
                      {selectedProject.client}
                    </span>
                  </div>
                </div>

                <div className="flex items-center gap-3">
                  <div className="p-2 rounded-full bg-white/5 text-gold">
                    <Calendar size={16} />
                  </div>
                  <div>
                    <span className="text-[10px] text-slate-400 font-medium uppercase block">Millésime</span>
                    <span className="text-xs font-bold text-white leading-none block">
                      {selectedProject.year}
                    </span>
                  </div>
                </div>

                <div className="flex items-center gap-3">
                  <div className="flex flex-wrap gap-1 leading-none">
                    <span className="text-[10px] text-slate-400 font-medium uppercase block w-full">Statut</span>
                    <span className="inline-flex items-center gap-1.5 px-2 py-0.5 rounded-full text-[10px] font-extrabold bg-gold/10 text-gold border border-gold/20">
                      <span className="w-1.5 h-1.5 rounded-full bg-gold" />
                      Actif
                    </span>
                  </div>
                </div>
              </div>

              <div className="mb-6">
                <h4 className="font-bold text-sm text-slate-200 mb-2">Description du projet</h4>
                <p className="text-slate-300 text-sm leading-relaxed">{selectedProject.description}</p>
              </div>

              <div>
                <h4 className="font-bold text-sm text-slate-200 mb-2">Stack Technique & Outils</h4>
                <div className="flex flex-wrap gap-2">
                  {selectedProject.techs.map((t, idx) => (
                    <span
                      key={idx}
                      className="px-3 py-1 bg-white/5 text-slate-300 border border-white/10 text-xs font-semibold rounded-lg"
                    >
                      {t}
                    </span>
                  ))}
                </div>
              </div>

              <button
                onClick={() => setSelectedProject(null)}
                className="mt-8 w-full py-3.5 bg-gold hover:bg-gold-light text-white font-bold rounded-xl transition"
              >
                Fermer l'aperçu
              </button>
            </div>
          </div>
        )}
      </div>
    </section>
  );
};
