import React from "react";
import { Mic, Radio, Music, Clapperboard, CheckCircle2 } from "lucide-react";

export default function AudioVideoSection() {
  return (
    <section
      id="audiovisuel"
      className="py-24 bg-gradient-to-br from-slate-900 via-slate-800 to-indigo-950 text-white overflow-hidden relative"
    >
      {/* Decorative Blur */}
      <div className="absolute top-1/2 left-0 w-80 h-80 rounded-full bg-amber-400/5 filter blur-[100px] pointer-events-none" />

      <div className="max-w-7xl mx-auto px-6 relative z-10">
        <div className="grid grid-cols-1 lg:grid-cols-2 gap-12 items-center">
          {/* Left Text */}
          <div className="flex flex-col text-left">
            <span className="text-amber-400 font-bold text-xs uppercase tracking-widest block mb-3">
              Studio audiovisuel
            </span>
            <h2 className="font-display font-bold text-3xl sm:text-4xl text-white leading-tight mb-6">
              Une identité sonore et visuelle marquante
            </h2>
            <p className="text-slate-300 text-base leading-relaxed mb-8 italic">
              Notre studio produit des contenus sonores et visuels de qualité studio professionnelle pour ancrer durablement l'image de votre marque dans l'esprit de vos clients.
            </p>

            {/* List with icons */}
            <ul className="space-y-4 list-none p-0 mb-8">
              {[
                { title: "Spots publicitaires originaux pour radio, TV et web", icon: <Clapperboard className="w-5 h-5 text-amber-400" /> },
                { title: "Voix-off claires adaptées à vos formations et documentaires", icon: <Mic className="w-5 h-5 text-amber-400" /> },
                { title: "Jingles personnalisés et musiques d'accueil mémorables", icon: <Music className="w-5 h-5 text-amber-400" /> },
                { title: "Montages narratifs rythmés et étalonnages cinéma", icon: <Radio className="w-5 h-5 text-amber-400" /> }
              ].map((item, index) => (
                <li
                  key={index}
                  className="flex items-center gap-3 font-semibold text-sm hover:text-amber-300 transition-all duration-300 hover:translate-x-1.5"
                >
                  <div className="p-1.5 rounded-lg bg-white/5 border border-white/10 shrink-0">
                    {item.icon}
                  </div>
                  <span>{item.title}</span>
                </li>
              ))}
            </ul>

            <a
              href="#contact"
              className="bg-amber-400 hover:bg-white text-slate-900 font-bold px-8 py-3.5 rounded-lg transition-all duration-300 transform hover:-translate-y-0.5 shadow-lg shadow-amber-400/20 w-max"
            >
              Demander une production
            </a>
          </div>

          {/* Right Image with beautiful hover border */}
          <div className="relative group">
            <div className="absolute -inset-1 bg-gradient-to-r from-amber-400 to-amber-300 rounded-xl blur opacity-30 group-hover:opacity-60 transition duration-1000 group-hover:duration-250" />
            <div className="relative rounded-xl overflow-hidden shadow-2xl border border-white/10">
              <img
                src="https://images.unsplash.com/photo-1598488035139-bdbb2231ce04?w=700&q=80"
                alt="Studio d'enregistrement audio professionnel"
                className="w-full h-auto object-cover transform scale-100 group-hover:scale-105 transition-transform duration-700 ease-out"
              />
            </div>
          </div>
        </div>
      </div>
    </section>
  );
}
