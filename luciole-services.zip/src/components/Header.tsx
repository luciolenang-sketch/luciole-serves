import React, { useState, useEffect } from "react";
import { Menu, X, Rocket } from "lucide-react";
import Logo from "./Logo";

export default function Header() {
  const [isOpen, setIsOpen] = useState(false);
  const [scrolled, setScrolled] = useState(false);

  useEffect(() => {
    const handleScroll = () => {
      setScrolled(window.scrollY > 10);
    };
    window.addEventListener("scroll", handleScroll);
    return () => window.removeEventListener("scroll", handleScroll);
  }, []);

  return (
    <header
      className={`fixed top-0 left-0 right-0 z-50 transition-all duration-300 ${
        scrolled
          ? "bg-white/95 backdrop-blur-md shadow-sm border-b border-slate-200 py-3"
          : "bg-white border-b border-slate-100 py-4"
      }`}
    >
      <div className="max-w-7xl mx-auto px-6 flex items-center justify-between h-12">
        {/* Logo */}
        <a href="#accueil" className="flex items-center gap-2 group">
          <Logo className="w-9 h-9 text-slate-900 group-hover:text-amber-600 transition-all duration-300" color="currentColor" />
          <span className="font-display font-bold text-xl sm:text-2xl text-slate-900 tracking-tight transition-colors duration-300 underline underline-offset-4 decoration-amber-400 group-hover:decoration-slate-900">
            LUCIOLE SERVICES
          </span>
        </a>

        {/* Desktop Nav */}
        <nav className="hidden md:flex items-center gap-8">
          <ul className="flex items-center gap-8 list-none m-0 p-0">
            {["Accueil", "Services", "Realisations", "Audiovisuel", "Apropos"].map((item) => (
              <li key={item}>
                <a
                  href={`#${item.toLowerCase()}`}
                  className="font-medium text-sm text-slate-600 hover:text-slate-900 relative py-1 transition-colors duration-200"
                >
                  {item === "Realisations"
                    ? "Réalisations"
                    : item === "Apropos"
                    ? "À propos"
                    : item}
                </a>
              </li>
            ))}
          </ul>
          <a
            href="#contact"
            className="px-5 py-2.5 bg-slate-900 hover:bg-amber-400 text-white hover:text-slate-950 rounded-lg font-bold text-sm transition-all duration-300 shadow-md hover:shadow-amber-400/25 shrink-0"
          >
            Demander un devis
          </a>
        </nav>

        {/* Mobile menu toggle */}
        <button
          onClick={() => setIsOpen(!isOpen)}
          className="md:hidden text-slate-900 focus:outline-none hover:text-amber-500 transition-colors duration-200"
          aria-label="Toggle menu"
        >
          {isOpen ? <X className="w-6 h-6" /> : <Menu className="w-6 h-6" />}
        </button>
      </div>

      {/* Mobile Nav Overlay */}
      {isOpen && (
        <div className="md:hidden absolute top-[100%] left-0 w-full bg-white shadow-xl border-t border-slate-200 flex flex-col p-6 gap-6 animate-fadeIn z-50">
          <ul className="flex flex-col gap-4 list-none p-0 m-0">
            {["Accueil", "Services", "Realisations", "Audiovisuel", "Apropos"].map((item) => (
              <li key={item}>
                <a
                  href={`#${item.toLowerCase()}`}
                  onClick={() => setIsOpen(false)}
                  className="font-bold text-base text-slate-800 hover:text-amber-500 block transition-colors duration-200"
                >
                  {item === "Realisations"
                    ? "Réalisations"
                    : item === "Apropos"
                    ? "À propos"
                    : item}
                </a>
              </li>
            ))}
          </ul>
          <a
            href="#contact"
            onClick={() => setIsOpen(false)}
            className="bg-slate-900 hover:bg-amber-400 text-white hover:text-slate-900 text-center py-3 rounded-lg font-bold text-sm transition-all duration-300 shadow-md"
          >
            Demander un devis
          </a>
        </div>
      )}
    </header>
  );
}
