import React from "react";
import { Star } from "lucide-react";

const testimonials = [
  {
    id: "testi-1",
    stars: 5,
    content: "Une équipe à l'écoute qui a transformé notre idée en une application fluide et particulièrement agréable à utiliser au quotidien par nos équipes. Je recommande vivement !",
    author: "Aïcha N.",
    location: "Entrepreneure, Douala",
    image: "https://images.unsplash.com/photo-1544005313-94ddf0286df2?w=120&auto=format&fit=crop&q=80"
  },
  {
    id: "testi-2",
    stars: 5,
    content: "Notre nouveau site de marque a complètement repensé notre approche client et boosté notre présence. Un accompagnement exceptionnel, très pro et disponible de bout en bout.",
    author: "Junior K.",
    location: "Directeur commercial, Yaoundé",
    image: "https://images.unsplash.com/photo-1507003211169-0a1dd7228f2d?w=120&auto=format&fit=crop&q=80"
  },
  {
    id: "testi-3",
    stars: 5,
    content: "Le jingle sonore signature créé pour notre entreprise est parfait d'élégance numérique. Il colle à la perfection à notre ADN de marque. Un grand merci au pôle audiovisuel.",
    author: "Sandrine M.",
    location: "Responsable marketing, Douala",
    image: "https://images.unsplash.com/photo-1534528741775-53994a69daeb?w=120&auto=format&fit=crop&q=80"
  }
];

export default function Testimonials() {
  return (
    <section className="py-24 bg-white border-t border-slate-100">
      <div className="max-w-7xl mx-auto px-6">
        {/* Section Heading */}
        <div className="text-center max-w-2xl mx-auto mb-16">
          <span className="text-amber-600 font-bold text-xs uppercase tracking-widest block mb-3">
            Témoignages
          </span>
          <h2 className="font-display font-bold text-3xl sm:text-4xl text-slate-900 leading-tight mb-4">
            Ce que disent nos clients satisfaits
          </h2>
          <p className="text-slate-500 text-sm sm:text-base leading-relaxed italic">
            La perfection et la fidélité de nos clients sont au cœur de nos réalisations.
          </p>
        </div>

        {/* Testimonials Grid */}
        <div className="grid grid-cols-1 md:grid-cols-3 gap-8">
          {testimonials.map((testimonial) => (
            <div
              key={testimonial.id}
              className="bg-slate-50 rounded-2xl p-8 shadow-sm hover:shadow-xl hover:shadow-slate-200/50 hover:border-amber-400 transition-all duration-300 flex flex-col justify-between border border-slate-200"
            >
              <div>
                {/* Rating stars */}
                <div className="flex gap-1 mb-5">
                  {Array.from({ length: testimonial.stars }).map((_, idx) => (
                    <Star key={idx} className="w-4 h-4 fill-amber-400 text-amber-400" />
                  ))}
                </div>

                <p className="text-slate-700 text-sm sm:text-base italic leading-relaxed mb-6">
                  &ldquo;{testimonial.content}&rdquo;
                </p>
              </div>

              {/* Author panel */}
              <div className="flex items-center gap-4 mt-auto pt-6 border-t border-slate-250">
                <img
                  src={testimonial.image}
                  alt={testimonial.author}
                  className="w-12 h-12 rounded-full object-cover border-2 border-white shadow-sm"
                />
                <div>
                  <h5 className="font-display font-bold text-sm text-slate-900">
                    {testimonial.author}
                  </h5>
                  <span className="text-xs text-slate-500 font-semibold">
                    {testimonial.location}
                  </span>
                </div>
              </div>
            </div>
          ))}
        </div>
      </div>
    </section>
  );
}
