export interface Slide {
  id: number;
  image: string;
  tag: string;
  title: string;
  alt: string;
}

export interface Service {
  id: string;
  icon: string; // we can map icons to Lucide components
  title: string;
  description: string;
}

export interface Project {
  id: string;
  title: string;
  category: "sites" | "apps";
  image: string;
  description: string;
}

export interface Testimonial {
  id: string;
  stars: number;
  content: string;
  author: string;
  location: string;
  image: string;
}
